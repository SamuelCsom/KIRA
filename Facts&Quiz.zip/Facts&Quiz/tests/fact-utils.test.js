const test = require('node:test');
const assert = require('node:assert/strict');

const factUtils = require('../fact-utils.js');

global.FactUtils = factUtils;
global.QuizData = require('../quiz-data.js');

const quizUtils = require('../quiz-utils.js');

const {
  validateFactsPayload,
  getCategories,
  filterFacts,
  pickRandomFact,
  pickRandomItem,
  buildEmptyStateMessage,
  sanitizeSettings,
  ALL_CATEGORIES,
  DEFAULT_SETTINGS,
} = factUtils;

const {
  sanitizeQuizScore,
  getFactsByCategory,
  pickRandomQuestion,
  createFalseStatement,
  generateTrueFalseQuestion,
  generateQuizQuestion,
  getCorrectAnswerLabel,
  updateQuizScore,
  buildAnswerFeedback,
  QUIZ_SCORE_KEY,
  DEFAULT_QUIZ_SCORE,
} = quizUtils;

const samplePayload = {
  facts: [
    { id: 'space-banana', text: 'Mercury is the closest planet to the Sun.', category: 'Space', subject: 'Mercury', difficulty: 'easy', quizModes: ['true_false', 'multiple_choice'] },
    { id: 'space-venus', text: 'Venus is the hottest planet in the Solar System.', category: 'Space', subject: 'Venus', difficulty: 'medium', quizModes: ['true_false'] },
    { id: 'science-water', text: 'Water is made of hydrogen and oxygen.', category: 'Science', subject: 'Water', difficulty: 'easy', quizModes: ['true_false'] },
  ],
};

const sampleFacts = validateFactsPayload(samplePayload);

test('validateFactsPayload normalizes valid facts to true/false mode only', () => {
  const facts = validateFactsPayload(samplePayload);
  assert.equal(facts.length, 3);
  assert.equal(facts[0].subject, 'Mercury');
  assert.deepEqual(facts[0].quizModes, ['true_false']);
});

test('getCategories includes All plus distinct categories', () => {
  assert.deepEqual(getCategories(sampleFacts), [ALL_CATEGORIES, 'Space', 'Science']);
});

test('filterFacts respects category and favorites filters', () => {
  const filtered = filterFacts(sampleFacts, { category: 'Science', favoritesOnly: true, favoriteIds: ['science-water'] });
  assert.deepEqual(filtered.map((fact) => fact.id), ['science-water']);
});

test('pickRandomItem avoids repeating the last item when possible', () => {
  const originalRandom = Math.random;
  Math.random = () => 0;
  const picked = pickRandomItem(sampleFacts, 'space-banana');
  assert.notEqual(picked.id, 'space-banana');
  Math.random = originalRandom;
});

test('pickRandomFact proxies to generic item picker', () => {
  const picked = pickRandomFact(sampleFacts, 'space-venus');
  assert.ok(sampleFacts.some((fact) => fact.id === picked.id));
});

test('buildEmptyStateMessage explains empty favorites state', () => {
  assert.match(buildEmptyStateMessage({ favoritesOnly: true }), /favorites/i);
});

test('sanitizeSettings falls back to defaults for unknown category', () => {
  const sanitized = sanitizeSettings({ defaultCategory: 'Unknown', defaultMode: 'quiz' }, [ALL_CATEGORIES, 'Science']);
  assert.equal(sanitized.defaultCategory, ALL_CATEGORIES);
  assert.equal(sanitized.defaultMode, 'quiz');
  assert.equal(DEFAULT_SETTINGS.defaultMode, 'facts');
});

test('quiz defaults stay stable for correct and wrong counters', () => {
  assert.equal(QUIZ_SCORE_KEY, 'randomSmartFacts.quizScore');
  assert.deepEqual(DEFAULT_QUIZ_SCORE, { correct: 0, wrong: 0 });
});

test('sanitizeQuizScore keeps only correct and wrong counters', () => {
  assert.deepEqual(sanitizeQuizScore({ correct: 5, wrong: 3, totalTrueFalse: 2 }), { correct: 5, wrong: 3 });
});

test('getFactsByCategory returns either one category or all facts', () => {
  assert.equal(getFactsByCategory(sampleFacts, 'Science').length, 1);
  assert.equal(getFactsByCategory(sampleFacts, ALL_CATEGORIES).length, 3);
});

test('false question generation swaps a relevant term for another believable one', () => {
  const falseStatement = createFalseStatement(sampleFacts[0], sampleFacts.filter((fact) => fact.category === 'Space'));
  assert.equal(falseStatement, 'Mercury is the farthest planet to the Sun.');
});

test('false question generation prefers value swaps for sentence-like subjects', () => {
  const facts = validateFactsPayload({
    facts: [
      {
        id: 'space-light',
        text: 'Light from the Sun takes about 8 minutes to reach Earth.',
        category: 'Space',
        subject: 'Light from the Sun takes about 8 minutes to reach Earth',
      },
    ],
  });

  const falseStatement = createFalseStatement(facts[0], facts);
  assert.equal(falseStatement, 'Light from the Sun takes about 8 seconds to reach Earth.');
});

test('generateTrueFalseQuestion can build a false true/false question', () => {
  const originalRandom = Math.random;
  Math.random = () => 0;
  const question = generateTrueFalseQuestion(sampleFacts[0], sampleFacts.filter((fact) => fact.category === 'Space'), { forceStatement: 'false' });
  assert.equal(question.type, 'true_false');
  assert.equal(question.correctAnswer, 'False');
  assert.equal(question.explanation, 'The Sun is an average-sized star, not the largest star in the universe.');
  assert.equal(question.statement, 'The Sun is the largest star in the universe.');
  Math.random = originalRandom;
});

test('generateTrueFalseQuestion can use curated false statements for animals', () => {
  const originalRandom = Math.random;
  Math.random = () => 0;

  const facts = validateFactsPayload({
    facts: [
      {
        id: 'animals-shark',
        text: 'Sharks are fish.',
        category: 'Animals',
        subject: 'Sharks',
      },
    ],
  });

  const question = generateTrueFalseQuestion(facts[0], facts, { forceStatement: 'false' });
  assert.equal(question.correctAnswer, 'False');
  assert.equal(question.explanation, 'Sharks are fish, not mammals.');
  assert.equal(question.statement, 'Sharks are mammals because they give live birth.');

  Math.random = originalRandom;
});

test('generateTrueFalseQuestion can use curated false statements for nature', () => {
  const originalRandom = Math.random;
  Math.random = () => 0;

  const facts = validateFactsPayload({
    facts: [
      {
        id: 'nature-tree',
        text: 'Trees make food through photosynthesis.',
        category: 'Nature',
        subject: 'Trees',
      },
    ],
  });

  const question = generateTrueFalseQuestion(facts[0], facts, { forceStatement: 'false' });
  assert.equal(question.correctAnswer, 'False');
  assert.equal(question.explanation, 'Trees make most of their food through photosynthesis, not directly from the soil.');
  assert.equal(question.statement, 'Trees get most of their food directly from the soil.');

  Math.random = originalRandom;
});

test('generateTrueFalseQuestion can use curated false statements for history', () => {
  const originalRandom = Math.random;
  Math.random = () => 0;

  const facts = validateFactsPayload({
    facts: [
      {
        id: 'history-caesar',
        text: 'Julius Caesar was a Roman general and dictator.',
        category: 'History',
        subject: 'Julius Caesar',
      },
    ],
  });

  const question = generateTrueFalseQuestion(facts[0], facts, { forceStatement: 'false' });
  assert.equal(question.correctAnswer, 'False');
  assert.equal(question.explanation, 'Julius Caesar was not the first emperor of Rome; Augustus is usually considered the first Roman emperor.');
  assert.equal(question.statement, 'Julius Caesar was the first emperor of Rome.');

  Math.random = originalRandom;
});

test('generateTrueFalseQuestion can use curated false statements for technology', () => {
  const originalRandom = Math.random;
  Math.random = () => 0;

  const facts = validateFactsPayload({
    facts: [
      {
        id: 'technology-web',
        text: 'The internet and the World Wide Web are not the same thing.',
        category: 'Technology',
        subject: 'The internet and the World Wide Web',
      },
    ],
  });

  const question = generateTrueFalseQuestion(facts[0], facts, { forceStatement: 'false' });
  assert.equal(question.correctAnswer, 'False');
  assert.equal(question.explanation, 'The internet and the World Wide Web are not the same thing.');
  assert.equal(question.statement, 'The internet and the World Wide Web are exactly the same thing.');

  Math.random = originalRandom;
});

test('generateTrueFalseQuestion can use curated false statements for science', () => {
  const originalRandom = Math.random;
  Math.random = () => 0;

  const facts = validateFactsPayload({
    facts: [
      {
        id: 'science-theory',
        text: 'A scientific theory is a well-supported explanation.',
        category: 'Science',
        subject: 'A scientific theory',
      },
    ],
  });

  const question = generateTrueFalseQuestion(facts[0], facts, { forceStatement: 'false' });
  assert.equal(question.correctAnswer, 'False');
  assert.equal(question.explanation, 'Science has explained many natural phenomena, but many major mysteries still remain.');
  assert.equal(question.statement, 'Science has already explained every major mystery in the universe.');

  Math.random = originalRandom;
});

test('generateQuizQuestion always returns true_false now', () => {
  const question = generateQuizQuestion(sampleFacts[0], sampleFacts, { forceStatement: 'true' });
  assert.equal(question.type, 'true_false');
});

test('generateTrueFalseQuestion falls back to a true statement when no false variant exists naturally', () => {
  const originalRandom = Math.random;
  Math.random = () => 0.9;

  const facts = validateFactsPayload({
    facts: [
      {
        id: 'history-only',
        text: 'Guilds existed.',
        category: 'History',
        subject: 'Guilds',
      },
    ],
  });

  const question = generateTrueFalseQuestion(facts[0], facts);
  assert.equal(question.correctAnswer, 'True');
  assert.equal(question.statement, 'Guilds existed.');

  Math.random = originalRandom;
});

test('pickRandomQuestion avoids immediate repeats when possible', () => {
  const originalRandom = Math.random;
  Math.random = () => 0;
  const picked = pickRandomQuestion(sampleFacts, 'space-banana');
  assert.notEqual(picked.id, 'space-banana');
  Math.random = originalRandom;
});

test('getCorrectAnswerLabel returns the stored answer', () => {
  const question = generateTrueFalseQuestion(sampleFacts[0], sampleFacts, { forceStatement: 'true' });
  assert.equal(getCorrectAnswerLabel(question), question.correctAnswer);
});

test('buildAnswerFeedback reveals the correct answer after a wrong response', () => {
  const question = {
    correctAnswer: 'False',
    explanation: 'Mercury is the closest planet to the Sun.',
  };
  const feedback = buildAnswerFeedback(question, 'True', { showExplanation: true });
  assert.equal(feedback.isCorrect, false);
  assert.match(feedback.message, /Wrong\. Correct answer: False\./);
  assert.match(feedback.message, /Original fact: Mercury is the closest planet to the Sun\./);
});

test('updateQuizScore tracks correct and wrong answers separately', () => {
  let score = updateQuizScore(DEFAULT_QUIZ_SCORE, true);
  score = updateQuizScore(score, false);
  assert.deepEqual(score, { correct: 1, wrong: 1 });
});
