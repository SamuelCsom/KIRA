const defaultCategorySelect = document.getElementById('default-category');
const defaultModeSelect = document.getElementById('default-mode');
const autoRefreshCheckbox = document.getElementById('auto-refresh-on-open');
const defaultFavoritesOnlyCheckbox = document.getElementById('default-favorites-only');
const showExplanationsCheckbox = document.getElementById('show-explanations');
const autoNextQuestionCheckbox = document.getElementById('auto-next-question');
const settingsForm = document.getElementById('settings-form');
const optionsStatus = document.getElementById('options-status');
const resetFavoritesButton = document.getElementById('reset-favorites-btn');
const resetScoreButton = document.getElementById('reset-score-btn');
const resetProgressButton = document.getElementById('reset-progress-btn');
const resetLocalStateButton = document.getElementById('reset-local-state-btn');

const { SETTINGS_KEY, FAVORITES_KEY, DEFAULT_SETTINGS, validateFactsPayload, getCategories, sanitizeSettings } = FactUtils;
const { getStorageArea, storageGet, storageSet } = StorageHelpers;
const { QUIZ_SCORE_KEY, DEFAULT_QUIZ_SCORE } = QuizUtils;
const CURRENT_FACT_KEY = 'randomSmartFacts.currentFactId';
const VIEWED_FACT_IDS_KEY = 'randomSmartFacts.viewedFactIds';
const FACT_ROTATION_STATE_KEY = 'randomSmartFacts.factRotationState';

function setStatus(message, show = true) {
  optionsStatus.textContent = message;
  optionsStatus.hidden = !show || !message;
}

async function loadFacts() {
  const response = await fetch(chrome.runtime.getURL('facts.json'));
  if (!response.ok) {
    throw new Error(`Failed to fetch facts.json (${response.status})`);
  }
  return validateFactsPayload(await response.json());
}

function renderCategoryOptions(categories, selectedCategory) {
  defaultCategorySelect.innerHTML = '';
  categories.forEach((category) => {
    const option = document.createElement('option');
    option.value = category;
    option.textContent = category;
    option.selected = category === selectedCategory;
    defaultCategorySelect.appendChild(option);
  });
}

async function initializeOptions() {
  try {
    const facts = await loadFacts();
    const categories = getCategories(facts);
    const storedSettings = await storageGet(getStorageArea('sync'), SETTINGS_KEY).catch(() => null);
    const settings = sanitizeSettings(storedSettings, categories);

    renderCategoryOptions(categories, settings.defaultCategory);
    defaultModeSelect.value = settings.defaultMode;
    autoRefreshCheckbox.checked = settings.autoRefreshOnOpen;
    defaultFavoritesOnlyCheckbox.checked = settings.defaultFavoritesOnly;
    showExplanationsCheckbox.checked = settings.showExplanations;
    autoNextQuestionCheckbox.checked = settings.autoNextQuestion;
  } catch (error) {
    renderCategoryOptions([FactUtils.ALL_CATEGORIES], DEFAULT_SETTINGS.defaultCategory);
    defaultModeSelect.value = DEFAULT_SETTINGS.defaultMode;
    autoRefreshCheckbox.checked = DEFAULT_SETTINGS.autoRefreshOnOpen;
    defaultFavoritesOnlyCheckbox.checked = DEFAULT_SETTINGS.defaultFavoritesOnly;
    showExplanationsCheckbox.checked = DEFAULT_SETTINGS.showExplanations;
    autoNextQuestionCheckbox.checked = DEFAULT_SETTINGS.autoNextQuestion;
    setStatus('Could not fully load settings. Default values are shown.');
    console.error(error);
  }
}

settingsForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    await storageSet(getStorageArea('sync'), {
      [SETTINGS_KEY]: {
        defaultCategory: defaultCategorySelect.value,
        defaultMode: defaultModeSelect.value,
        autoRefreshOnOpen: autoRefreshCheckbox.checked,
        defaultFavoritesOnly: defaultFavoritesOnlyCheckbox.checked,
        showExplanations: showExplanationsCheckbox.checked,
        autoNextQuestion: autoNextQuestionCheckbox.checked,
      },
    });
    setStatus('Settings saved. The popup will use them next time it opens.');
  } catch (error) {
    setStatus('Settings could not be saved. Please try again.');
    console.error(error);
  }
});

resetFavoritesButton.addEventListener('click', async () => {
  try {
    await storageSet(getStorageArea('local'), { [FAVORITES_KEY]: [] });
    setStatus('Favorites were reset.');
  } catch (error) {
    setStatus('Favorites could not be reset.');
    console.error(error);
  }
});

resetScoreButton.addEventListener('click', async () => {
  try {
    await storageSet(getStorageArea('local'), { [QUIZ_SCORE_KEY]: DEFAULT_QUIZ_SCORE });
    setStatus('Quiz score was reset.');
  } catch (error) {
    setStatus('Quiz score could not be reset.');
    console.error(error);
  }
});

resetProgressButton.addEventListener('click', async () => {
  try {
    await storageSet(getStorageArea('local'), { [VIEWED_FACT_IDS_KEY]: [] });
    setStatus('Viewed facts progress was reset.');
  } catch (error) {
    setStatus('Viewed facts progress could not be reset.');
    console.error(error);
  }
});

resetLocalStateButton.addEventListener('click', async () => {
  try {
    await storageSet(getStorageArea('local'), {
      [FAVORITES_KEY]: [],
      [QUIZ_SCORE_KEY]: DEFAULT_QUIZ_SCORE,
      [CURRENT_FACT_KEY]: null,
      [VIEWED_FACT_IDS_KEY]: [],
      [FACT_ROTATION_STATE_KEY]: {},
    });
    setStatus('Local favorites, quiz score, progress, and last fact were reset.');
  } catch (error) {
    setStatus('Local state could not be reset.');
    console.error(error);
  }
});

initializeOptions();
