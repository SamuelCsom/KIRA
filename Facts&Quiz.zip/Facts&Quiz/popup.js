const factText = document.getElementById('fact-text');
const factCategory = document.getElementById('fact-category');
const statusText = document.getElementById('status-text');
const newFactButton = document.getElementById('new-fact-btn');
const favoriteButton = document.getElementById('favorite-btn');
const popupToolbar = document.getElementById('popup-toolbar');
const categorySelect = document.getElementById('category-select');
const favoritesOnlyToggle = document.getElementById('favorites-only-toggle');
const factsModeButton = document.getElementById('facts-mode-btn');
const progressModeButton = document.getElementById('progress-mode-btn');
const quizModeButton = document.getElementById('quiz-mode-btn');
const factsPanel = document.getElementById('facts-panel');
const progressPanel = document.getElementById('progress-panel');
const quizPanel = document.getElementById('quiz-panel');
const progressSeenCount = document.getElementById('progress-seen-count');
const progressTotalCount = document.getElementById('progress-total-count');
const progressPercent = document.getElementById('progress-percent');
const progressList = document.getElementById('progress-list');
const progressStatus = document.getElementById('progress-status');
const resetProgressButton = document.getElementById('reset-progress-btn');
const quizScoreCorrect = document.getElementById('quiz-score-correct');
const quizScoreWrong = document.getElementById('quiz-score-wrong');
const quizCategoryHint = document.getElementById('quiz-category-hint');
const quizQuestion = document.getElementById('quiz-question');
const quizOptions = document.getElementById('quiz-options');
const quizFeedback = document.getElementById('quiz-feedback');
const nextQuestionButton = document.getElementById('next-question-btn');

const { FAVORITES_KEY, SETTINGS_KEY, ALL_CATEGORIES, filterFacts, validateFactsPayload, getCategories, sanitizeSettings } = FactUtils;
const { getStorageArea, storageGet, storageSet } = StorageHelpers;
const { QUIZ_SCORE_KEY, DEFAULT_QUIZ_SCORE, sanitizeQuizScore, updateQuizScore } = QuizUtils;
const CURRENT_FACT_KEY = 'randomSmartFacts.currentFactId';
const VIEWED_FACT_IDS_KEY = 'randomSmartFacts.viewedFactIds';
const FACT_ROTATION_STATE_KEY = 'randomSmartFacts.factRotationState';

let factsCache = null;
let favoriteIds = [];
let settings = { ...FactUtils.DEFAULT_SETTINGS };
let activeMode = 'facts';
let currentQuizScore = { ...DEFAULT_QUIZ_SCORE };
let storedCurrentFactId = null;
let viewedFactIds = [];
let factRotationState = {};
let factRefreshPromise = null;

function logError(context, error) {
  console.error(context, error);
}

async function loadFacts() {
  if (factsCache) {
    return factsCache;
  }

  const response = await fetch(chrome.runtime.getURL('facts.json'));
  if (!response.ok) {
    throw new Error(`Failed to fetch facts.json (${response.status})`);
  }

  factsCache = validateFactsPayload(await response.json());
  return factsCache;
}

function setStatus(message, isVisible = true) {
  statusText.textContent = message;
  statusText.hidden = !isVisible || !message;
}

function setProgressStatus(message, isVisible = true) {
  progressStatus.textContent = message;
  progressStatus.hidden = !isVisible || !message;
}

function updateFavoriteButton(currentFact) {
  if (!currentFact) {
    favoriteButton.textContent = '\u2606';
    favoriteButton.setAttribute('aria-pressed', 'false');
    favoriteButton.disabled = true;
    return;
  }

  const isFavorite = favoriteIds.includes(currentFact.id);
  favoriteButton.textContent = isFavorite ? '\u2605' : '\u2606';
  favoriteButton.setAttribute('aria-pressed', String(isFavorite));
  favoriteButton.setAttribute('aria-label', isFavorite ? 'Remove current fact from favorites' : 'Save current fact to favorites');
  favoriteButton.disabled = false;
}

function renderCategoryOptions(categories, selectedCategory) {
  categorySelect.innerHTML = '';
  categories.forEach((category) => {
    const option = document.createElement('option');
    option.value = category;
    option.textContent = category;
    option.selected = category === selectedCategory;
    categorySelect.appendChild(option);
  });
}

function renderQuizScore() {
  quizScoreCorrect.textContent = String(currentQuizScore.correct);
  quizScoreWrong.textContent = String(currentQuizScore.wrong);
}

function setFactLoadingState(isLoading) {
  const hasCurrentFact = Boolean(factsController?.getCurrentFact?.());
  newFactButton.disabled = isLoading || !hasCurrentFact;
  categorySelect.disabled = isLoading;
  favoritesOnlyToggle.disabled = isLoading;
  favoriteButton.disabled = isLoading || !hasCurrentFact;

  if (!isLoading) {
    updateFavoriteButton(factsController?.getCurrentFact?.() || null);
  }
}

function sanitizeViewedFactIds(rawViewedFactIds) {
  if (!Array.isArray(rawViewedFactIds)) {
    return [];
  }

  const uniqueIds = new Set();
  return rawViewedFactIds.filter((id) => {
    if (typeof id !== 'string' || !id || uniqueIds.has(id)) {
      return false;
    }

    uniqueIds.add(id);
    return true;
  });
}

function sanitizeFactRotationState(rawRotationState) {
  if (!rawRotationState || typeof rawRotationState !== 'object' || Array.isArray(rawRotationState)) {
    return {};
  }

  return Object.entries(rawRotationState).reduce((state, [filterKey, shownIds]) => {
    if (typeof filterKey !== 'string' || !filterKey) {
      return state;
    }

    state[filterKey] = sanitizeViewedFactIds(shownIds);
    return state;
  }, {});
}

function buildProgressSnapshot(facts) {
  const categories = getCategories(facts).filter((category) => category !== ALL_CATEGORIES);
  const validFactIds = new Set(facts.map((fact) => fact.id));
  const seenFactIds = new Set(viewedFactIds.filter((factId) => validFactIds.has(factId)));
  const categoryStats = categories.map((category) => {
    const categoryFacts = facts.filter((fact) => fact.category === category);
    const seenCount = categoryFacts.reduce((count, fact) => count + (seenFactIds.has(fact.id) ? 1 : 0), 0);
    const totalCount = categoryFacts.length;
    const percentage = totalCount === 0 ? 0 : Math.round((seenCount / totalCount) * 100);

    return { category, seenCount, totalCount, percentage };
  });

  return {
    totalFacts: facts.length,
    seenFacts: seenFactIds.size,
    percentage: facts.length === 0 ? 0 : Math.round((seenFactIds.size / facts.length) * 100),
    categoryStats,
  };
}

function renderProgress() {
  const facts = factsCache || [];
  const snapshot = buildProgressSnapshot(facts);

  progressSeenCount.textContent = String(snapshot.seenFacts);
  progressTotalCount.textContent = String(snapshot.totalFacts);
  progressPercent.textContent = `${snapshot.percentage}%`;
  progressList.innerHTML = '';

  if (snapshot.categoryStats.length === 0) {
    const emptyState = document.createElement('p');
    emptyState.className = 'progress-empty';
    emptyState.textContent = 'Progress will appear here as soon as facts are available.';
    progressList.appendChild(emptyState);
    return;
  }

  snapshot.categoryStats.forEach((stat) => {
    const row = document.createElement('article');
    row.className = 'progress-row';

    const header = document.createElement('div');
    header.className = 'progress-row-head';

    const title = document.createElement('span');
    title.className = 'progress-row-title';
    title.textContent = stat.category;

    const meta = document.createElement('span');
    meta.className = 'progress-row-meta';
    meta.textContent = `${stat.seenCount} / ${stat.totalCount} seen`;

    header.append(title, meta);

    const track = document.createElement('div');
    track.className = 'progress-track';
    track.setAttribute('aria-hidden', 'true');

    const fill = document.createElement('div');
    fill.className = 'progress-fill';
    fill.style.width = `${stat.percentage}%`;

    track.appendChild(fill);

    row.append(header, track);
    progressList.appendChild(row);
  });
}

async function saveQuizScore() {
  await storageSet(getStorageArea('local'), {
    [QUIZ_SCORE_KEY]: {
      ...currentQuizScore,
    },
  });
}

function applyScoreUpdate(isCorrect) {
  currentQuizScore = updateQuizScore(currentQuizScore, isCorrect);
}

async function loadStoredState(categories) {
  const [storedFavorites, storedSettings, storedQuizScore, savedCurrentFactId, storedViewedFactIds, storedFactRotationState] = await Promise.all([
    storageGet(getStorageArea('local'), FAVORITES_KEY).catch(() => []),
    storageGet(getStorageArea('sync'), SETTINGS_KEY).catch(() => null),
    storageGet(getStorageArea('local'), QUIZ_SCORE_KEY).catch(() => DEFAULT_QUIZ_SCORE),
    storageGet(getStorageArea('local'), CURRENT_FACT_KEY).catch(() => null),
    storageGet(getStorageArea('local'), VIEWED_FACT_IDS_KEY).catch(() => []),
    storageGet(getStorageArea('local'), FACT_ROTATION_STATE_KEY).catch(() => ({})),
  ]);

  favoriteIds = Array.isArray(storedFavorites) ? storedFavorites : [];
  settings = sanitizeSettings(storedSettings, categories);
  currentQuizScore = sanitizeQuizScore(storedQuizScore);
  storedCurrentFactId = typeof savedCurrentFactId === 'string' && savedCurrentFactId ? savedCurrentFactId : null;
  viewedFactIds = sanitizeViewedFactIds(storedViewedFactIds);
  factRotationState = sanitizeFactRotationState(storedFactRotationState);
}

async function saveFavorites() {
  await storageSet(getStorageArea('local'), { [FAVORITES_KEY]: favoriteIds });
}

async function saveCurrentFactId(factId) {
  storedCurrentFactId = typeof factId === 'string' && factId ? factId : null;
  await storageSet(getStorageArea('local'), { [CURRENT_FACT_KEY]: storedCurrentFactId });
}

async function saveViewedFactIds() {
  await storageSet(getStorageArea('local'), { [VIEWED_FACT_IDS_KEY]: viewedFactIds });
}

async function saveFactRotationState() {
  await storageSet(getStorageArea('local'), { [FACT_ROTATION_STATE_KEY]: factRotationState });
}

function persistFactRotationState() {
  saveFactRotationState().catch((error) => {
    logError('Failed to save fact rotation state.', error);
  });
}

function getShownIdsForFilter(filterKey) {
  return factRotationState[filterKey] || [];
}

function setShownIdsForFilter(filterKey, shownIds) {
  factRotationState = {
    ...factRotationState,
    [filterKey]: sanitizeViewedFactIds(shownIds),
  };
  persistFactRotationState();
}

function clearShownIdsForFilter(filterKey) {
  if (!Object.prototype.hasOwnProperty.call(factRotationState, filterKey)) {
    return;
  }

  const { [filterKey]: _removed, ...nextState } = factRotationState;
  factRotationState = nextState;
  persistFactRotationState();
}

async function markFactAsViewed(fact, options = {}) {
  if (!fact?.id || viewedFactIds.includes(fact.id)) {
    renderProgress();
    return;
  }

  const previousViewedFactIds = [...viewedFactIds];
  viewedFactIds = [...viewedFactIds, fact.id];
  renderProgress();

  try {
    await saveViewedFactIds();
  } catch (error) {
    viewedFactIds = previousViewedFactIds;
    renderProgress();
    if (!options.suppressStatus) {
      setStatus(options.errorMessage || 'The fact was shown, but progress could not be saved.');
    }
    logError('Failed to save viewed facts progress.', error);
  }
}

async function showAndPersistFact(options) {
  const fact = await factsController.showRandomFact(options);
  try {
    await saveCurrentFactId(fact?.id || null);
  } catch (error) {
    setStatus('The fact was shown, but we could not save your last-viewed state.');
    logError('Failed to save current fact state.', error);
  }
  return fact;
}

async function refreshFactView(options = {}, errorMessage = "Couldn't load a new fact right now. Please try again.") {
  if (factRefreshPromise) {
    return factRefreshPromise;
  }

  factRefreshPromise = (async () => {
    setStatus('', false);
    setFactLoadingState(true);

    try {
      const fact = await showAndPersistFact(options);
      if (activeMode === 'facts') {
        await markFactAsViewed(fact);
      }
      updateFavoriteButton(fact);
      return fact;
    } catch (error) {
      updateFavoriteButton(factsController.getCurrentFact());
      setStatus(errorMessage);
      logError('Failed to refresh fact view.', error);
      return null;
    } finally {
      setFactLoadingState(false);
      factRefreshPromise = null;
    }
  })();

  return factRefreshPromise;
}

async function showQuizQuestion(errorMessage = "Couldn't load a quiz question right now. Please try again.") {
  try {
    await quizController.showNextQuestion();
  } catch (error) {
    quizController.showQuestionLoadError(errorMessage);
    logError('Failed to load quiz question.', error);
  }
}

function getRestoredFact(facts) {
  if (!storedCurrentFactId) {
    return null;
  }

  const visibleFacts = filterFacts(facts, factsController.getActiveFilters());
  return visibleFacts.find((fact) => fact.id === storedCurrentFactId) || null;
}

const factsController = PopupFacts.createFactsController(
  { factText, factCategory, categorySelect, favoritesOnlyToggle, newFactButton },
  loadFacts,
  () => favoriteIds,
  setStatus,
  {
    getShownIds: getShownIdsForFilter,
    setShownIds: setShownIdsForFilter,
    clearShownIds: clearShownIdsForFilter,
  }
);
const quizController = PopupQuiz.createQuizController(
  { categorySelect, quizCategoryHint, quizQuestion, quizOptions, quizFeedback, nextQuestionButton },
  {
    ALL_CATEGORIES,
    getFacts: loadFacts,
    getAutoNext: () => settings.autoNextQuestion,
    getShowExplanation: () => settings.showExplanations,
    onAnswered: async (_question, isCorrect) => {
      applyScoreUpdate(isCorrect);
      renderQuizScore();
      try {
        await saveQuizScore();
        return { scoreSaved: true };
      } catch (error) {
        logError('Failed to save quiz score.', error);
        return {
          scoreSaved: false,
          warningMessage: 'Your answer was checked, but the quiz score could not be saved.',
        };
      }
    },
    showNextQuestion: () => showQuizQuestion(),
  }
);

function setActiveMode(mode) {
  activeMode = mode;
  const isFactsMode = mode === 'facts';
  const isProgressMode = mode === 'progress';
  const isQuizMode = mode === 'quiz';

  factsModeButton.classList.toggle('is-active', isFactsMode);
  factsModeButton.setAttribute('aria-pressed', String(isFactsMode));
  progressModeButton.classList.toggle('is-active', isProgressMode);
  progressModeButton.setAttribute('aria-pressed', String(isProgressMode));
  quizModeButton.classList.toggle('is-active', isQuizMode);
  quizModeButton.setAttribute('aria-pressed', String(isQuizMode));

  factsPanel.hidden = !isFactsMode;
  progressPanel.hidden = !isProgressMode;
  quizPanel.hidden = !isQuizMode;
  popupToolbar.hidden = isProgressMode;

  if (isProgressMode) {
    renderProgress();
    setProgressStatus('', false);
  }

  if (isFactsMode) {
    factsController.syncCurrentFactToRotation();
    void markFactAsViewed(factsController.getCurrentFact(), { suppressStatus: false });
  }

  if (isQuizMode) {
    showQuizQuestion();
  }
}

async function toggleFavorite() {
  const currentFact = factsController.getCurrentFact();
  if (!currentFact) {
    return;
  }

  const isFavorite = favoriteIds.includes(currentFact.id);
  const nextFavoriteIds = isFavorite ? favoriteIds.filter((id) => id !== currentFact.id) : [...favoriteIds, currentFact.id];

  favoriteIds = nextFavoriteIds;
  updateFavoriteButton(currentFact);

  try {
    await saveFavorites();
  } catch (error) {
    favoriteIds = isFavorite ? [...favoriteIds, currentFact.id] : favoriteIds.filter((id) => id !== currentFact.id);
    updateFavoriteButton(currentFact);
    setStatus('Your favorites could not be updated. Please try again.');
    logError('Failed to save favorites.', error);
    return;
  }

  if (favoritesOnlyToggle.checked && isFavorite) {
    await refreshFactView({}, "The favorite was removed, but we couldn't refresh the next fact.");
    return;
  }

  setStatus(isFavorite ? 'Removed from favorites.' : 'Saved to favorites.');
}

async function initializePopup() {
  try {
    const facts = await loadFacts();
    const categories = getCategories(facts);

    await loadStoredState(categories);
    renderCategoryOptions(categories, settings.defaultCategory);
    favoritesOnlyToggle.checked = settings.defaultFavoritesOnly;
    renderQuizScore();
    renderProgress();
    quizController.updateCategoryHint();

    let initialFact = null;

    if (settings.autoRefreshOnOpen) {
      setFactLoadingState(true);
      initialFact = await showAndPersistFact();
      setFactLoadingState(false);
    } else {
      const restoredFact = getRestoredFact(facts);
      if (restoredFact) {
        factsController.renderFact(restoredFact);
        factsController.setLastFactId(restoredFact.id);
        factsController.syncCurrentFactToRotation();
        try {
          await saveCurrentFactId(restoredFact.id);
        } catch (error) {
          setStatus('The last fact was restored, but we could not save popup state.');
          logError('Failed to persist restored fact state.', error);
        }
        initialFact = restoredFact;
      } else {
        initialFact = await showAndPersistFact();
      }
    }

    updateFavoriteButton(initialFact);
    setFactLoadingState(false);
    setActiveMode(settings.defaultMode || 'facts');
  } catch (error) {
    factText.textContent = "Sorry, we couldn't load facts right now. Please reload the extension and try again.";
    factCategory.textContent = 'Unavailable';
    newFactButton.disabled = true;
    favoriteButton.disabled = true;
    console.error(error);
  }
}

newFactButton.addEventListener('click', async () => {
  await refreshFactView();
});

categorySelect.addEventListener('change', async () => {
  await refreshFactView({ preserveCurrent: true }, "Couldn't update this category right now. Please try again.");
  quizController.resetSourceFactRotation();
  quizController.updateCategoryHint();
  if (activeMode === 'quiz') {
    await showQuizQuestion("Couldn't refresh the quiz for this category right now.");
  }
});

favoritesOnlyToggle.addEventListener('change', async () => {
  await refreshFactView({ preserveCurrent: true }, "Couldn't update the favorites filter right now. Please try again.");
});

favoriteButton.addEventListener('click', toggleFavorite);
factsModeButton.addEventListener('click', () => setActiveMode('facts'));
progressModeButton.addEventListener('click', () => setActiveMode('progress'));
quizModeButton.addEventListener('click', () => setActiveMode('quiz'));
nextQuestionButton.addEventListener('click', () => showQuizQuestion());
resetProgressButton.addEventListener('click', async () => {
  const previousViewedFactIds = [...viewedFactIds];
  viewedFactIds = [];
  renderProgress();
  setProgressStatus('', false);

  try {
    await saveViewedFactIds();
    setProgressStatus('Progress was reset.');
  } catch (error) {
    viewedFactIds = previousViewedFactIds;
    renderProgress();
    setProgressStatus('Progress could not be reset.');
    logError('Failed to reset viewed facts progress.', error);
  }
});
initializePopup();
