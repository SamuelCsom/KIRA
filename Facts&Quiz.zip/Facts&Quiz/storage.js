(function attachStorageHelpers(globalScope) {
  function getStorageArea(type) {
    return chrome?.storage?.[type] || null;
  }

  function storageGet(area, key) {
    return new Promise((resolve, reject) => {
      if (!area) {
        reject(new Error('Storage area is unavailable.'));
        return;
      }

      area.get(key, (result) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        resolve(result[key]);
      });
    });
  }

  function storageSet(area, values) {
    return new Promise((resolve, reject) => {
      if (!area) {
        reject(new Error('Storage area is unavailable.'));
        return;
      }

      area.set(values, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        resolve();
      });
    });
  }

  const api = { getStorageArea, storageGet, storageSet };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }

  globalScope.StorageHelpers = api;
})(typeof globalThis !== 'undefined' ? globalThis : window);
