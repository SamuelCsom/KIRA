#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { validateFactsPayload } = require('../fact-utils.js');

const filePath = path.resolve(__dirname, '..', 'facts.json');

try {
  const raw = fs.readFileSync(filePath, 'utf8');
  const payload = JSON.parse(raw);
  const facts = validateFactsPayload(payload);
  const categories = [...new Set(facts.map((fact) => fact.category))];

  console.log(`facts.json is valid: ${facts.length} facts across ${categories.length} categories.`);
} catch (error) {
  console.error(`facts.json validation failed: ${error.message}`);
  process.exitCode = 1;
}
