const fs = require("fs");
const path = require("path");

const root = process.cwd();
const githubPage = path.join(root, "github-page");
const templateDir = path.join(root, "scripts", "pptx-template-inspect");
const buildDir = path.join(root, "scripts", "pptx-build");
const outputPath = path.join(githubPage, "FactsAndQuiz-presentation.pptx");

const COLORS = {
  bg: "0B1430",
  panel: "16244C",
  panelStrong: "1B2C5B",
  line: "2A3D75",
  text: "EEF3FF",
  muted: "B8C8E8",
  accent: "8196FF",
  accent2: "56C7FF",
  accent3: "8FF0CA",
  warning: "FFD979",
  danger: "FF9EAA",
};

const SLIDE = {
  w: 9144000,
  h: 5143500,
};

function emu(value) {
  return Math.round(value * 914400);
}

function esc(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function ensureCleanDir(dir) {
  fs.rmSync(dir, { recursive: true, force: true });
  fs.mkdirSync(dir, { recursive: true });
}

function copyDir(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

function createTextShape(id, cfg) {
  const paragraphs = (cfg.paragraphs || []).map((p) => {
    const align = p.align || cfg.align || "l";
    const color = p.color || cfg.color || COLORS.text;
    const fontFace = p.fontFace || cfg.fontFace || "Inter";
    const size = p.size || cfg.size || 1800;
    const bold = p.bold || false;
    const italic = p.italic || false;
    const cap = p.cap ? ` cap="${p.cap}"` : "";
    const baseline = p.baseline ? ` baseline="${p.baseline}"` : "";
    return `<a:p><a:pPr algn="${align}"/><a:r><a:rPr lang="sk-SK" sz="${size}"${bold ? ' b="1"' : ""}${italic ? ' i="1"' : ""}${cap}${baseline}><a:solidFill><a:srgbClr val="${color}"/></a:solidFill><a:latin typeface="${esc(fontFace)}"/><a:ea typeface="${esc(fontFace)}"/><a:cs typeface="${esc(fontFace)}"/></a:rPr><a:t>${esc(
      p.text
    )}</a:t></a:r><a:endParaRPr lang="sk-SK" sz="${size}"><a:solidFill><a:srgbClr val="${color}"/></a:solidFill></a:endParaRPr></a:p>`;
  });

  const fill = cfg.fill
    ? `<a:solidFill><a:srgbClr val="${cfg.fill}"/></a:solidFill>`
    : "<a:noFill/>";
  const line = cfg.line
    ? `<a:ln w="12700"><a:solidFill><a:srgbClr val="${cfg.line}"/></a:solidFill></a:ln>`
    : "<a:ln><a:noFill/></a:ln>";
  const shape = cfg.shape || "roundRect";
  const anchor = cfg.anchor || "t";
  const lIns = cfg.insets?.left ?? 152400;
  const rIns = cfg.insets?.right ?? 152400;
  const tIns = cfg.insets?.top ?? 91440;
  const bIns = cfg.insets?.bottom ?? 91440;

  return `<p:sp>
    <p:nvSpPr>
      <p:cNvPr id="${id}" name="${esc(cfg.name || `Shape ${id}`)}"/>
      <p:cNvSpPr${cfg.txBox ? ' txBox="1"' : ""}/>
      <p:nvPr/>
    </p:nvSpPr>
    <p:spPr>
      <a:xfrm><a:off x="${cfg.x}" y="${cfg.y}"/><a:ext cx="${cfg.w}" cy="${cfg.h}"/></a:xfrm>
      <a:prstGeom prst="${shape}"><a:avLst/></a:prstGeom>
      ${fill}
      ${line}
    </p:spPr>
    <p:txBody>
      <a:bodyPr wrap="square" anchor="${anchor}" lIns="${lIns}" rIns="${rIns}" tIns="${tIns}" bIns="${bIns}"/>
      <a:lstStyle/>
      ${paragraphs.join("")}
    </p:txBody>
  </p:sp>`;
}

function createPicture(id, relId, cfg) {
  return `<p:pic>
    <p:nvPicPr>
      <p:cNvPr id="${id}" name="${esc(cfg.name || `Picture ${id}`)}"/>
      <p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr>
      <p:nvPr/>
    </p:nvPicPr>
    <p:blipFill>
      <a:blip r:embed="${relId}"/>
      <a:stretch><a:fillRect/></a:stretch>
    </p:blipFill>
    <p:spPr>
      <a:xfrm><a:off x="${cfg.x}" y="${cfg.y}"/><a:ext cx="${cfg.w}" cy="${cfg.h}"/></a:xfrm>
      <a:prstGeom prst="${cfg.shape || "roundRect"}"><a:avLst/></a:prstGeom>
      <a:ln w="12700"><a:solidFill><a:srgbClr val="${cfg.line || COLORS.line}"/></a:solidFill></a:ln>
    </p:spPr>
  </p:pic>`;
}

function createSlideXml(elements) {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:cSld>
    <p:spTree>
      <p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>
      <p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>
      ${elements.join("")}
    </p:spTree>
  </p:cSld>
  <p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>
</p:sld>`;
}

function createSlideRels(imageTargets) {
  const rels = [
    `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout7.xml"/>`,
  ];
  imageTargets.forEach((target, index) => {
    rels.push(
      `<Relationship Id="rId${index + 2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/${esc(
        target
      )}"/>`
    );
  });
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${rels.join("")}</Relationships>`;
}

function baseSlideElements(index, sectionLabel, title, subtitle) {
  const elements = [];
  let id = 10;
  elements.push(
    createTextShape(id++, {
      name: "Background",
      x: 0,
      y: 0,
      w: SLIDE.w,
      h: SLIDE.h,
      fill: COLORS.bg,
      line: COLORS.bg,
      paragraphs: [{ text: "" }],
      insets: { left: 0, right: 0, top: 0, bottom: 0 },
    })
  );
  elements.push(
    createTextShape(id++, {
      name: "Top pill",
      x: emu(0.42),
      y: emu(0.28),
      w: emu(2.25),
      h: emu(0.42),
      fill: COLORS.panelStrong,
      line: COLORS.line,
      paragraphs: [{ text: sectionLabel, size: 1150, color: COLORS.text, bold: true, cap: "all", fontFace: "Inter" }],
      anchor: "ctr",
      align: "ctr",
    })
  );
  elements.push(
    createTextShape(id++, {
      name: "Slide index",
      x: emu(8.5),
      y: emu(0.27),
      w: emu(1.0),
      h: emu(0.35),
      fill: COLORS.bg,
      line: COLORS.bg,
      paragraphs: [{ text: `0${index} / 09`, size: 1050, color: COLORS.muted, bold: true, fontFace: "Space Grotesk" }],
      align: "r",
      txBox: true,
      insets: { left: 0, right: 0, top: 0, bottom: 0 },
    })
  );
  elements.push(
    createTextShape(id++, {
      name: "Title",
      x: emu(0.42),
      y: emu(0.82),
      w: emu(5.4),
      h: emu(0.75),
      fill: COLORS.bg,
      line: COLORS.bg,
      paragraphs: [{ text: title, size: 2600, color: COLORS.text, bold: true, fontFace: "Space Grotesk" }],
      txBox: true,
      insets: { left: 0, right: 0, top: 0, bottom: 0 },
    })
  );
  if (subtitle) {
    elements.push(
      createTextShape(id++, {
        name: "Subtitle",
        x: emu(0.42),
        y: emu(1.43),
        w: emu(6.2),
        h: emu(0.52),
        fill: COLORS.bg,
        line: COLORS.bg,
        paragraphs: [{ text: subtitle, size: 1100, color: COLORS.muted, fontFace: "Inter" }],
        txBox: true,
        insets: { left: 0, right: 0, top: 0, bottom: 0 },
      })
    );
  }
  return { elements, nextId: id };
}

function addCard(elements, idStart, x, y, w, h, heading, body, opts = {}) {
  let id = idStart;
  elements.push(
    createTextShape(id++, {
      x,
      y,
      w,
      h,
      fill: opts.fill || COLORS.panel,
      line: opts.line || COLORS.line,
      paragraphs: [
        {
          text: heading,
          size: opts.headingSize || 1080,
          color: opts.headingColor || COLORS.text,
          bold: true,
          cap: opts.headingCap || "all",
          fontFace: "Inter",
        },
        {
          text: body,
          size: opts.bodySize || 980,
          color: opts.bodyColor || COLORS.muted,
          fontFace: "Inter",
        },
      ],
      anchor: "t",
      insets: { left: emu(0.16), right: emu(0.16), top: emu(0.12), bottom: emu(0.12) },
    })
  );
  return id;
}

const mediaFiles = [
  { key: "logo", file: "logo.png" },
  { key: "hero", file: "enjoy.png" },
  { key: "main", file: "img1.png" },
  { key: "open", file: "open_chrome_extension.png" },
  { key: "devmode", file: "turn_on_developer_mode.png" },
  { key: "load", file: "load_unpacked.png" },
  { key: "pin", file: "pin.png" },
  { key: "settings", file: "ukazka_settings.png" },
  { key: "progress", file: "ukazka_progress.png" },
  { key: "quiz", file: "ukazka_quiz.png" },
  { key: "qr", file: "qr-kira.png" },
];

function buildSlides() {
  const slides = [];

  // Slide 1
  {
    const { elements, nextId } = baseSlideElements(
      3,
      "Dotazn?k",
      "V?sledok dotazn?ku",
      "Aj na malej vzorke sa uk?zalo, ?e z?ujem o r?chle fakty aj quiz mechaniku je re?lny."
    );
    let id = nextId;
    elements.push(
      createPicture(id++, "rId2", {
        x: emu(6.0),
        y: emu(0.82),
        w: emu(3.15),
        h: emu(2.12),
        name: "Hero Image",
      })
    );
    elements.push(
      createTextShape(id++, {
        x: emu(0.42),
        y: emu(2.0),
        w: emu(4.8),
        h: emu(0.5),
        fill: COLORS.bg,
        line: COLORS.bg,
        paragraphs: [{ text: "Learn something fast.", size: 1600, color: COLORS.accent2, bold: true, fontFace: "Inter" }],
        txBox: true,
        insets: { left: 0, right: 0, top: 0, bottom: 0 },
      })
    );
    elements.push(
      createTextShape(id++, {
        x: emu(0.42),
        y: emu(2.52),
        w: emu(4.6),
        h: emu(1.05),
        fill: COLORS.bg,
        line: COLORS.bg,
        paragraphs: [
          {
            text: "Vizuál, flow aj obsah sú navrhnuté tak, aby učenie v prehliadači pôsobilo rýchlo, čisto a bez zbytočného trenia.",
            size: 1080,
            color: COLORS.muted,
            fontFace: "Inter",
          },
        ],
        txBox: true,
        insets: { left: 0, right: 0, top: 0, bottom: 0 },
      })
    );
    id = addCard(elements, id, emu(0.42), emu(3.8), emu(2.1), emu(0.72), "Autor", "Samuel Csom");
    id = addCard(elements, id, emu(2.7), emu(3.8), emu(2.1), emu(0.72), "Predmet", "Doplň podľa školy");
    id = addCard(elements, id, emu(4.98), emu(3.8), emu(1.55), emu(0.72), "Rok", "2026");
    id = addCard(elements, id, emu(6.72), emu(3.8), emu(2.15), emu(0.72), "Platforma", "Google Chrome");
    slides.push({
      images: ["hero.png"],
      mediaMap: { "hero.png": "hero" },
      xml: createSlideXml(elements),
    });
  }

  // Slide 2
  {
    const { elements, nextId } = baseSlideElements(
      2,
      "Prečo • Kto • Čo",
      "Produktový základ",
      "Krátke učenie vtedy, keď je používateľ už v prehliadači."
    );
    let id = nextId;
    elements.push(
      createPicture(id++, "rId2", {
        x: emu(6.2),
        y: emu(1.1),
        w: emu(2.55),
        h: emu(3.88),
        name: "Main Popup",
      })
    );
    id = addCard(
      elements,
      id,
      emu(0.42),
      emu(2.0),
      emu(5.2),
      emu(0.95),
      "Prečo?",
      "Používateľ nechce kvôli jednej zaujímavej informácii otvárať dlhý článok ani samostatnú appku."
    );
    id = addCard(
      elements,
      id,
      emu(0.42),
      emu(3.05),
      emu(5.2),
      emu(0.95),
      "Kto?",
      "Študenti, pracujúci ľudia a zvedaví používatelia, ktorí majú radi rýchle fakty a mini quiz."
    );
    id = addCard(
      elements,
      id,
      emu(0.42),
      emu(4.1),
      emu(5.2),
      emu(0.9),
      "Čo?",
      "Chrome extension, ktorá kombinuje facts, favorites, progress tracking a True / False quiz."
    );
    slides.push({
      images: ["main.png"],
      mediaMap: { "main.png": "main" },
      xml: createSlideXml(elements),
    });
  }

  // Slide 3
  {
    const { elements, nextId } = baseSlideElements(
      3,
      "Dotaznik",
      "Vysledok dotaznika",
      "Aj na malej vzorke sa ukazalo, ze zaujem o rychle fakty aj quiz mechaniku je realny."
    );
    let id = nextId;
    const kpis = [
      ["Respondenti", "7", "zakladna validacna vzorka"],
      ["Mimo skoly / prace", "85.7%", "bavi ich ucit sa nove veci"],
      ["Random fakty", "100%", "maju radi jednovetove fakty"],
      ["Quiz zaujem", "71.4%", "dalsich 14.3% odpovedalo skor ano"],
    ];
    kpis.forEach((item, idx) => {
      const x = emu(0.42 + idx * 2.35);
      elements.push(
        createTextShape(id++, {
          x,
          y: emu(2.05),
          w: emu(2.1),
          h: emu(0.95),
          fill: COLORS.panel,
          line: COLORS.line,
          paragraphs: [
            { text: item[0], size: 900, color: COLORS.text, bold: true, cap: "all", fontFace: "Inter" },
            { text: item[1], size: 2000, color: COLORS.text, bold: true, fontFace: "Space Grotesk" },
            { text: item[2], size: 840, color: COLORS.muted, fontFace: "Inter" },
          ],
        })
      );
    });
    const bars = [
      ["Bavi vas ucit sa nove veci aj mimo skoly / prace?", "85.7% ano", 0.857],
      ["Mate radi random jednovetove fakty?", "100% ano", 1.0],
      ["Chceli by ste moznost otestovat sa z precitanych faktov?", "71.4% ano", 0.714],
      ["Historia + Mind-blowing fakty", "85.7%", 0.857],
    ];
    elements.push(
      createTextShape(id++, {
        x: emu(0.42),
        y: emu(3.25),
        w: emu(9.0),
        h: emu(0.35),
        fill: COLORS.bg,
        line: COLORS.bg,
        paragraphs: [{ text: "Prehlad odpovedi", size: 1250, color: COLORS.text, bold: true, fontFace: "Space Grotesk" }],
        txBox: true,
        insets: { left: 0, right: 0, top: 0, bottom: 0 },
      })
    );
    bars.forEach((bar, idx) => {
      const y = 3.72 + idx * 0.48;
      elements.push(
        createTextShape(id++, {
          x: emu(0.42),
          y: emu(y),
          w: emu(6.8),
          h: emu(0.22),
          fill: COLORS.bg,
          line: COLORS.bg,
          paragraphs: [{ text: bar[0], size: 900, color: COLORS.mutedStrong || COLORS.muted, fontFace: "Inter" }],
          txBox: true,
          insets: { left: 0, right: 0, top: 0, bottom: 0 },
        })
      );
      elements.push(
        createTextShape(id++, {
          x: emu(7.35),
          y: emu(y),
          w: emu(1.2),
          h: emu(0.22),
          fill: COLORS.bg,
          line: COLORS.bg,
          paragraphs: [{ text: bar[1], size: 900, color: COLORS.text, bold: true, fontFace: "Inter" }],
          txBox: true,
          align: "r",
          insets: { left: 0, right: 0, top: 0, bottom: 0 },
        })
      );
      elements.push(
        createTextShape(id++, {
          x: emu(0.42),
          y: emu(y + 0.2),
          w: emu(8.0),
          h: emu(0.12),
          fill: "23345E",
          line: "23345E",
          paragraphs: [{ text: "" }],
          insets: { left: 0, right: 0, top: 0, bottom: 0 },
        })
      );
      elements.push(
        createTextShape(id++, {
          x: emu(0.42),
          y: emu(y + 0.2),
          w: emu(8.0 * bar[2]),
          h: emu(0.12),
          fill: idx === 1 ? COLORS.accent2 : COLORS.accent,
          line: idx === 1 ? COLORS.accent2 : COLORS.accent,
          paragraphs: [{ text: "" }],
          insets: { left: 0, right: 0, top: 0, bottom: 0 },
        })
      );
    });
    elements.push(
      createTextShape(id++, {
        x: emu(0.42),
        y: emu(5.42),
        w: emu(8.7),
        h: emu(0.32),
        fill: COLORS.bg,
        line: COLORS.bg,
        paragraphs: [
          {
            text: "Open feedback: respondenti spomenuli najma notifikacie a zabavnejsi charakter pouzivania.",
            size: 820,
            color: COLORS.warning,
            fontFace: "Inter",
          },
        ],
        txBox: true,
        insets: { left: 0, right: 0, top: 0, bottom: 0 },
      })
    );
    slides.push({ images: [], mediaMap: {}, xml: createSlideXml(elements) });
  }

  // Slide 4
  {
    const { elements, nextId } = baseSlideElements(
      4,
      "MVP",
      "Prvá použiteľná verzia",
      "Cieľ bol od začiatku vytvoriť produkt, ku ktorému sa používateľ bude vracať."
    );
    let id = nextId;
    const cards = [
      ["Facts popup", "Kurátorované fakty v čistom popup rozhraní."],
      ["Kategórie", "Filtrovanie naprieč 6 vedomostnými oblasťami."],
      ["Favorites", "Ukladanie faktov pre neskorší návrat."],
      ["Progress", "Sledovanie otvorených true factov podľa kategórie."],
      ["True / False quiz", "Rýchly switch z čítania na overenie vedomostí."],
      ["Settings", "Predvolené nastavenia správania a quiz flow."],
    ];
    cards.forEach((card, idx) => {
      const col = idx % 3;
      const row = Math.floor(idx / 3);
      id = addCard(
        elements,
        id,
        emu(0.42 + col * 3.05),
        emu(2.0 + row * 1.22),
        emu(2.75),
        emu(1.0),
        card[0],
        card[1],
        { headingCap: "", bodySize: 900, headingSize: 1200 }
      );
    });
    slides.push({ images: [], mediaMap: {}, xml: createSlideXml(elements) });
  }

  // Slide 5
  {
    const { elements, nextId } = baseSlideElements(
      5,
      "Tunnel",
      "Od stránky po inštaláciu",
      "Produkt má jednoduchý onboarding: prezentácia → download → Chrome extensions → Load unpacked."
    );
    let id = nextId;
    const steps = [
      ["Landing page", "Projekt sa vysvetlí vizuálne a bez zahltenia textom.", "hero.png"],
      ["Chrome extensions", "Používateľ sa dostane do správnej časti prehliadača.", "open.png"],
      ["Load unpacked", "Po rozbalení ZIPu sa appka načíta ako lokálna build verzia.", "load.png"],
      ["Pin & use", "Po pripnutí sa používanie stáva rýchlym zvykom.", "pin.png"],
    ];
    steps.forEach((step, idx) => {
      const x = 0.42 + idx * 2.35;
      elements.push(
        createTextShape(id++, {
          x: emu(x),
          y: emu(2.0),
          w: emu(2.1),
          h: emu(2.55),
          fill: COLORS.panel,
          line: COLORS.line,
          paragraphs: [
            { text: `${idx + 1}`, size: 1000, color: COLORS.accent2, bold: true, fontFace: "Space Grotesk" },
            { text: step[0], size: 1200, color: COLORS.text, bold: true, fontFace: "Inter" },
            { text: step[1], size: 860, color: COLORS.muted, fontFace: "Inter" },
          ],
          insets: { left: emu(0.12), right: emu(0.12), top: emu(0.12), bottom: emu(0.12) },
        })
      );
      elements.push(
        createPicture(id++, `rId${idx + 2}`, {
          x: emu(x + 0.1),
          y: emu(2.8),
          w: emu(1.9),
          h: emu(1.08),
          name: step[0],
          shape: "roundRect",
        })
      );
    });
    slides.push({
      images: ["hero.png", "open.png", "load.png", "pin.png"],
      mediaMap: { "hero.png": "hero", "open.png": "open", "load.png": "load", "pin.png": "pin" },
      xml: createSlideXml(elements),
    });
  }

  // Slide 6
  {
    const { elements, nextId } = baseSlideElements(
      6,
      "Demo",
      "Samotná aplikácia",
      "V malom priestore ponúka tri režimy práce s rovnakým obsahom: fact browsing, progress tracking a quiz."
    );
    let id = nextId;
    elements.push(createPicture(id++, "rId2", { x: emu(0.42), y: emu(2.0), w: emu(3.0), h: emu(2.82), name: "Main popup" }));
    elements.push(createPicture(id++, "rId3", { x: emu(3.62), y: emu(2.0), w: emu(2.12), h: emu(2.75), name: "Progress" }));
    elements.push(createPicture(id++, "rId4", { x: emu(5.94), y: emu(2.0), w: emu(2.12), h: emu(2.55), name: "Quiz" }));
    elements.push(createPicture(id++, "rId5", { x: emu(6.08), y: emu(4.25), w: emu(3.0), h: emu(1.18), name: "Settings", shape: "rect" }));
    id = addCard(elements, id, emu(0.42), emu(4.95), emu(2.65), emu(0.42), "Facts mode", "jedno silné tvrdenie + kategória + favorites", {
      headingCap: "",
      headingSize: 1080,
      bodySize: 760,
    });
    id = addCard(elements, id, emu(3.25), emu(4.95), emu(2.35), emu(0.42), "Progress", "koľko true factov bolo už otvorených", {
      headingCap: "",
      headingSize: 1080,
      bodySize: 760,
    });
    id = addCard(elements, id, emu(5.78), emu(4.95), emu(3.1), emu(0.42), "Quiz + Settings", "opakované používanie a personalizácia", {
      headingCap: "",
      headingSize: 1080,
      bodySize: 760,
    });
    slides.push({
      images: ["main.png", "progress.png", "quiz.png", "settings.png"],
      mediaMap: { "main.png": "main", "progress.png": "progress", "quiz.png": "quiz", "settings.png": "settings" },
      xml: createSlideXml(elements),
    });
  }

  // Slide 7
  {
    const { elements, nextId } = baseSlideElements(
      7,
      "Technické záležitosti",
      "Ako je to postavené",
      "Riešenie je malé, rýchle a ľahko upraviteľné aj bez frameworku."
    );
    let id = nextId;
    const techCards = [
      ["Frontend", "HTML, CSS a Vanilla JavaScript. Rýchly popup bez zbytočnej závislosti od frameworku."],
      ["Chrome platforma", "Manifest V3, popup okno, options page a chrome.storage pre lokálny stav."],
      ["Dáta", "906 faktov v JSON datasete rozdelených do 6 kategórií."],
      ["Logika", "Facts / Favorites / Progress / Quiz / Settings sú rozdelené do menších JS modulov."],
    ];
    techCards.forEach((card, idx) => {
      const col = idx % 2;
      const row = Math.floor(idx / 2);
      id = addCard(
        elements,
        id,
        emu(0.42 + col * 4.45),
        emu(2.0 + row * 1.28),
        emu(4.05),
        emu(1.05),
        card[0],
        card[1],
        { headingCap: "", bodySize: 900, headingSize: 1200 }
      );
    });
    slides.push({ images: [], mediaMap: {}, xml: createSlideXml(elements) });
  }

  // Slide 8
  {
    const { elements, nextId } = baseSlideElements(
      8,
      "Spätná väzba",
      "Čo z feedbacku vyplynulo",
      "Najsilnejší insight bol, že podobné produkty často berú novú kartu, no používateľ chce rýchly popup bez veľkého zásahu."
    );
    let id = nextId;
    const fb = [
      ["Zdroj", "Chrome Web Store konkurencia", "Mnohé podobné riešenia fungujú ako new-tab dashboard."],
      ["Feedback", "Používateľ chce rýchlosť", "Hodnota musí prísť hneď po kliknutí, bez prepínania workflow."],
      ["Odpoveď", "Popup-first prístup", "Vznikol čistý popup s faktami, favorites, progress a quiz režimom."],
      ["Ponaučenie", "Menej plochy, viac hodnoty", "Malý produkt vyhráva jasným use-case a nie množstvom prvkov."],
    ];
    fb.forEach((item, idx) => {
      id = addCard(
        elements,
        id,
        emu(0.42 + idx * 2.27),
        emu(2.15),
        emu(2.05),
        emu(2.3),
        item[0],
        `${item[1]}\n${item[2]}`,
        { headingCap: "", bodySize: 860, headingSize: 1150 }
      );
    });
    slides.push({ images: [], mediaMap: {}, xml: createSlideXml(elements) });
  }

  // Slide 9
  {
    const { elements, nextId } = baseSlideElements(
      9,
      "Call to action",
      "Scan, open, try",
      "QR kód smeruje na live stránku projektu. Odtiaľ sa dá pokračovať k inštalácii a ďalším materiálom."
    );
    let id = nextId;
    elements.push(createPicture(id++, "rId2", { x: emu(6.25), y: emu(1.55), w: emu(2.7), h: emu(2.7), name: "QR Code", shape: "rect", line: "FFFFFF" }));
    id = addCard(
      elements,
      id,
      emu(0.42),
      emu(2.1),
      emu(5.2),
      emu(0.92),
      "Live page",
      "https://samuelcsom.github.io/KIRA/",
      { headingCap: "", bodySize: 920, headingSize: 1150 }
    );
    id = addCard(
      elements,
      id,
      emu(0.42),
      emu(3.18),
      emu(5.2),
      emu(0.92),
      "GitHub repository",
      "https://github.com/SamuelCsom/KIRA",
      { headingCap: "", bodySize: 920, headingSize: 1150 }
    );
    id = addCard(
      elements,
      id,
      emu(0.42),
      emu(4.26),
      emu(5.2),
      emu(0.92),
      "Direct ZIP",
      "https://samuelcsom.github.io/KIRA/github-page/Fun-Fuckt-main.zip",
      { headingCap: "", bodySize: 820, headingSize: 1150 }
    );
    slides.push({
      images: ["qr.png"],
      mediaMap: { "qr.png": "qr" },
      xml: createSlideXml(elements),
    });
  }

  return slides;
}

function writeSlides(buildPath, slides, mediaNameMap) {
  const slidesDir = path.join(buildPath, "ppt", "slides");
  const relsDir = path.join(slidesDir, "_rels");
  fs.mkdirSync(slidesDir, { recursive: true });
  fs.mkdirSync(relsDir, { recursive: true });

  slides.forEach((slide, index) => {
    const slideNum = index + 1;
    fs.writeFileSync(path.join(slidesDir, `slide${slideNum}.xml`), slide.xml, "utf8");
    const relTargets = slide.images.map((imageName) => mediaNameMap[slide.mediaMap[imageName]]);
    fs.writeFileSync(path.join(relsDir, `slide${slideNum}.xml.rels`), createSlideRels(relTargets), "utf8");
  });
}

function updatePresentation(buildPath, slideCount) {
  const slideIds = [];
  for (let i = 0; i < slideCount; i += 1) {
    slideIds.push(`<p:sldId id="${256 + i}" r:id="rId${i + 2}"/>`);
  }
  const presentationXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" removePersonalInfoOnSave="1" saveSubsetFonts="1"><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:notesMasterIdLst><p:notesMasterId r:id="rId10"/></p:notesMasterIdLst><p:sldIdLst>${slideIds.join(
    ""
  )}</p:sldIdLst><p:sldSz cx="${SLIDE.w}" cy="${SLIDE.h}" type="screen16x9"/><p:notesSz cx="6858000" cy="9144000"/><p:defaultTextStyle><a:lvl1pPr marL="0" algn="l" rtl="0" latinLnBrk="0"><a:defRPr sz="1800" kern="1200" lang="sk-SK"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl1pPr><a:lvl2pPr marL="457200" algn="l" rtl="0" latinLnBrk="0"><a:defRPr sz="1800" kern="1200" lang="sk-SK"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl2pPr><a:lvl3pPr marL="914400" algn="l" rtl="0" latinLnBrk="0"><a:defRPr sz="1800" kern="1200" lang="sk-SK"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl3pPr><a:lvl4pPr marL="1371600" algn="l" rtl="0" latinLnBrk="0"><a:defRPr sz="1800" kern="1200" lang="sk-SK"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl4pPr><a:lvl5pPr marL="1828800" algn="l" rtl="0" latinLnBrk="0"><a:defRPr sz="1800" kern="1200" lang="sk-SK"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl5pPr><a:lvl6pPr marL="2286000" algn="l" rtl="0" latinLnBrk="0"><a:defRPr sz="1800" kern="1200" lang="sk-SK"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl6pPr><a:lvl7pPr marL="2743200" algn="l" rtl="0" latinLnBrk="0"><a:defRPr sz="1800" kern="1200" lang="sk-SK"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl7pPr><a:lvl8pPr marL="3200400" algn="l" rtl="0" latinLnBrk="0"><a:defRPr sz="1800" kern="1200" lang="sk-SK"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl8pPr><a:lvl9pPr marL="3657600" algn="l" rtl="0" latinLnBrk="0"><a:defRPr sz="1800" kern="1200" lang="sk-SK"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl9pPr><a:extLst/></p:defaultTextStyle></p:presentation>`;

  const presentationRels = [];
  for (let i = 0; i < slideCount; i += 1) {
    presentationRels.push(
      `<Relationship Id="rId${i + 2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${
        i + 1
      }.xml"/>`
    );
  }
  const relXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>${presentationRels.join(
    ""
  )}<Relationship Id="rId10" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/notesMaster" Target="notesMasters/notesMaster1.xml"/><Relationship Id="rId11" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/presProps" Target="presProps.xml"/><Relationship Id="rId12" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/viewProps" Target="viewProps.xml"/><Relationship Id="rId13" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme/theme1.xml"/><Relationship Id="rId14" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/tableStyles" Target="tableStyles.xml"/></Relationships>`;

  fs.writeFileSync(path.join(buildPath, "ppt", "presentation.xml"), presentationXml, "utf8");
  fs.writeFileSync(path.join(buildPath, "ppt", "_rels", "presentation.xml.rels"), relXml, "utf8");
}

function updateContentTypes(buildPath, slideCount) {
  const filePath = path.join(buildPath, "[Content_Types].xml");
  let xml = fs.readFileSync(filePath, "utf8");
  xml = xml.replace(
    'ContentType="application/vnd.openxmlformats-officedocument.presentationml.template.main+xml"',
    'ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"'
  );
  if (!xml.includes('/ppt/slides/slide9.xml')) {
    xml = xml.replace(
      "</Types>",
      `<Override PartName="/ppt/slides/slide9.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/></Types>`
    );
  }
  fs.writeFileSync(filePath, xml, "utf8");
}

function updateCoreProps(buildPath) {
  const corePath = path.join(buildPath, "docProps", "core.xml");
  const now = new Date().toISOString();
  const coreXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>Facts&amp;Quiz Presentation</dc:title><dc:creator>Samuel Csom</dc:creator><cp:lastModifiedBy>OpenAI Codex</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">${now}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${now}</dcterms:modified></cp:coreProperties>`;
  fs.writeFileSync(corePath, coreXml, "utf8");
}

function updateAppProps(buildPath) {
  const appPath = path.join(buildPath, "docProps", "app.xml");
  const appXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Microsoft Office PowerPoint</Application><PresentationFormat>On-screen Show (16:9)</PresentationFormat><Company></Company><Slides>9</Slides><Notes>0</Notes><HiddenSlides>0</HiddenSlides><MMClips>0</MMClips><ScaleCrop>false</ScaleCrop><HeadingPairs><vt:vector size="2" baseType="variant"><vt:variant><vt:lpstr>Slides</vt:lpstr></vt:variant><vt:variant><vt:i4>9</vt:i4></vt:variant></vt:vector></HeadingPairs><TitlesOfParts><vt:vector size="9" baseType="lpstr"><vt:lpstr>Identita</vt:lpstr><vt:lpstr>Produktový základ</vt:lpstr><vt:lpstr>Výsledok dotazníku</vt:lpstr><vt:lpstr>Prvá použiteľná verzia</vt:lpstr><vt:lpstr>Od stránky po inštaláciu</vt:lpstr><vt:lpstr>Samotná aplikácia</vt:lpstr><vt:lpstr>Ako je to postavené</vt:lpstr><vt:lpstr>Čo z feedbacku vyplynulo</vt:lpstr><vt:lpstr>Scan, open, try</vt:lpstr></vt:vector></TitlesOfParts></Properties>`;
  fs.writeFileSync(appPath, appXml, "utf8");
}

function copyMedia(buildPath) {
  const mediaDir = path.join(buildPath, "ppt", "media");
  fs.mkdirSync(mediaDir, { recursive: true });
  const mediaNameMap = {};
  mediaFiles.forEach((item) => {
    const src = path.join(githubPage, item.file);
    if (!fs.existsSync(src)) {
      throw new Error(`Missing asset: ${src}`);
    }
    const outName = `fxq-${item.key}${path.extname(item.file).toLowerCase()}`;
    fs.copyFileSync(src, path.join(mediaDir, outName));
    mediaNameMap[item.key] = outName;
  });
  return mediaNameMap;
}

function main() {
  if (!fs.existsSync(templateDir)) {
    throw new Error(`Template directory not found: ${templateDir}`);
  }
  if (!fs.existsSync(path.join(githubPage, "qr-kira.png"))) {
    throw new Error("QR image missing. Expected github-page/qr-kira.png");
  }

  ensureCleanDir(buildDir);
  copyDir(templateDir, buildDir);
  const mediaNameMap = copyMedia(buildDir);
  const slides = buildSlides();
  writeSlides(buildDir, slides, mediaNameMap);
  updatePresentation(buildDir, slides.length);
  updateContentTypes(buildDir, slides.length);
  updateCoreProps(buildDir);
  updateAppProps(buildDir);
  if (fs.existsSync(outputPath)) {
    fs.unlinkSync(outputPath);
  }
  console.log(`Build prepared in ${buildDir}`);
}

main();
