(function attachQuizUtils(globalScope) {
  const { ALL_CATEGORIES, pickRandomItem } = globalScope.FactUtils || {};
  const { CATEGORY_TERMS = {}, NUMBER_REPLACEMENTS = {}, CURATED_FALSE_STATEMENTS = {} } = globalScope.QuizData || {};
  const QUIZ_SCORE_KEY = 'randomSmartFacts.quizScore';
  const DEFAULT_QUIZ_SCORE = {
    correct: 0,
    wrong: 0,
  };

  function sanitizeQuizScore(rawScore) {
    const correct = Number.isInteger(rawScore?.correct) && rawScore.correct >= 0 ? rawScore.correct : 0;
    const wrong = Number.isInteger(rawScore?.wrong) && rawScore.wrong >= 0 ? rawScore.wrong : 0;
    return { correct, wrong };
  }

  function getFactsByCategory(facts, category) {
    if (!Array.isArray(facts)) return [];
    if (!category || category === ALL_CATEGORIES) return [...facts];
    return facts.filter((fact) => fact.category === category);
  }

  function pickRandomQuestion(items, lastQuestionId) {
    return pickRandomItem ? pickRandomItem(items, lastQuestionId) : null;
  }

  function normalizeCuratedFalseEntry(entry, category, index) {
    if (typeof entry === 'string') {
      return {
        id: `${category}-false-${index}`,
        statement: entry,
        explanation: '',
      };
    }

    if (entry && typeof entry === 'object' && typeof entry.statement === 'string') {
      return {
        id: `${category}-false-${index}`,
        statement: entry.statement,
        explanation: typeof entry.explanation === 'string' ? entry.explanation : '',
      };
    }

    return null;
  }

  function pickCuratedFalseStatement(category) {
    const statements = Array.isArray(CURATED_FALSE_STATEMENTS[category]) ? CURATED_FALSE_STATEMENTS[category] : [];
    if (statements.length === 0) {
      return null;
    }

    const statementItems = statements
      .map((entry, index) => normalizeCuratedFalseEntry(entry, category, index))
      .filter(Boolean);

    if (statementItems.length === 0) {
      return null;
    }

    const pickedItem = pickRandomItem ? pickRandomItem(statementItems) : statementItems[Math.floor(Math.random() * statementItems.length)];
    return pickedItem || null;
  }

  function escapeRegExp(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function normalizeComparableText(value) {
    return String(value || '')
      .trim()
      .replace(/[.!?]+$/, '')
      .toLowerCase();
  }

  function getPhraseProfile(value) {
    const trimmedValue = String(value || '').trim();
    const words = trimmedValue ? trimmedValue.split(/\s+/) : [];
    const firstWord = words[0]?.toLowerCase() || '';

    return {
      wordCount: words.length,
      startsWithArticle: ['a', 'an', 'the'].includes(firstWord),
      startsWithCapital: /^[A-Z]/.test(trimmedValue),
      isAllCaps: Boolean(trimmedValue) && trimmedValue === trimmedValue.toUpperCase(),
    };
  }

  function preserveReplacementCase(source, replacement) {
    if (!source) return replacement;
    if (source === source.toUpperCase()) return replacement.toUpperCase();
    if (source[0] === source[0].toUpperCase()) return replacement[0].toUpperCase() + replacement.slice(1);
    return replacement;
  }

  function replaceExactTerm(text, searchValue, replaceValue) {
    const regex = new RegExp(`\\b${escapeRegExp(searchValue)}\\b`, 'i');
    const match = text.match(regex);
    if (!match) return null;
    return text.replace(regex, preserveReplacementCase(match[0], replaceValue));
  }

  function replaceUsingMap(text, replacementMap) {
    for (const [source, target] of Object.entries(replacementMap)) {
      const updated = replaceExactTerm(text, source, target);
      if (updated && updated !== text) {
        return updated;
      }
    }

    return null;
  }

  function isWholeSentenceSubject(subject, text) {
    return normalizeComparableText(subject) === normalizeComparableText(text);
  }

  function isCompatibleReplacementTerm(searchValue, candidate) {
    const searchProfile = getPhraseProfile(searchValue);
    const candidateProfile = getPhraseProfile(candidate);

    if (!searchProfile.wordCount || !candidateProfile.wordCount) {
      return false;
    }

    if (searchProfile.startsWithArticle !== candidateProfile.startsWithArticle) {
      return false;
    }

    if (searchProfile.isAllCaps !== candidateProfile.isAllCaps && (searchProfile.isAllCaps || candidateProfile.isAllCaps)) {
      return false;
    }

    if (!searchProfile.startsWithArticle && searchProfile.startsWithCapital !== candidateProfile.startsWithCapital) {
      return false;
    }

    return Math.abs(searchProfile.wordCount - candidateProfile.wordCount) <= 2;
  }

  function buildReplacementCandidates(fact, factsInCategory) {
    const subjectTerms = factsInCategory
      .filter((candidate) => candidate.id !== fact.id)
      .map((candidate) => candidate.subject)
      .filter((value) => typeof value === 'string' && value.trim());
    const categoryTerms = (CATEGORY_TERMS[fact.category] || []).filter((value) => typeof value === 'string' && value.trim());

    return [...new Set([...subjectTerms, ...categoryTerms])].filter((value) => value.toLowerCase() !== fact.subject.toLowerCase());
  }

  function getSearchableTerms(fact) {
    const categoryTerms = (CATEGORY_TERMS[fact.category] || []).filter((value) => typeof value === 'string' && value.trim());
    const rawTerms = [fact.subject, ...categoryTerms]
      .filter((value) => typeof value === 'string' && value.trim())
      .filter((value, index, values) => values.findIndex((entry) => entry.toLowerCase() === value.toLowerCase()) === index);

    return rawTerms
      .filter((term) => term.toLowerCase() !== fact.subject.toLowerCase() || !isWholeSentenceSubject(term, fact.text))
      .sort((left, right) => right.length - left.length);
  }

  function createFalseStatement(fact, factsInCategory) {
    const text = fact.text;
    const searchableTerms = getSearchableTerms(fact);
    const mappedReplacement = replaceUsingMap(text, NUMBER_REPLACEMENTS);

    if (mappedReplacement) {
      return mappedReplacement;
    }

    for (const term of searchableTerms) {
      const regex = new RegExp(`\\b${escapeRegExp(term)}\\b`, 'i');
      if (!regex.test(text)) {
        continue;
      }

      const replacement = buildReplacementCandidates(fact, factsInCategory).find((candidate) => {
        if (candidate.toLowerCase() === term.toLowerCase()) {
          return false;
        }
        if (new RegExp(`\\b${escapeRegExp(candidate)}\\b`, 'i').test(text)) {
          return false;
        }
        if (!isCompatibleReplacementTerm(term, candidate)) {
          return false;
        }
        return true;
      });

      if (replacement) {
        const updated = replaceExactTerm(text, term, replacement);
        if (updated && updated !== text) {
          return updated;
        }
      }
    }

    return null;
  }

  function generateTrueFalseQuestion(fact, factsInCategory, options = {}) {
    if (!fact) return null;

    const curatedFalseEntry = pickCuratedFalseStatement(fact.category);
    const falseStatement = curatedFalseEntry?.statement || createFalseStatement(fact, factsInCategory);
    const statementMode = options.forceStatement || (falseStatement && Math.random() >= 0.5 ? 'false' : 'true');

    if (statementMode === 'false') {
      if (!falseStatement) {
        return null;
      }
      return {
        id: `tf-${fact.id}-false`,
        sourceFactId: fact.id,
        category: fact.category,
        type: 'true_false',
        prompt: 'Decide whether this statement is true or false.',
        statement: falseStatement,
        correctAnswer: 'False',
        explanation: curatedFalseEntry?.explanation || fact.text,
      };
    }

    return {
      id: `tf-${fact.id}-true`,
      sourceFactId: fact.id,
      category: fact.category,
      type: 'true_false',
      prompt: 'Decide whether this statement is true or false.',
      statement: fact.text,
      correctAnswer: 'True',
      explanation: fact.text,
    };
  }

  function generateQuizQuestion(fact, factsInCategory, options) {
    return fact ? generateTrueFalseQuestion(fact, factsInCategory, options) : null;
  }

  function getCorrectAnswerLabel(item) {
    return item?.correctAnswer || '';
  }

  function updateQuizScore(score, isCorrect) {
    const safeScore = sanitizeQuizScore(score);
    return {
      correct: safeScore.correct + (isCorrect ? 1 : 0),
      wrong: safeScore.wrong + (isCorrect ? 0 : 1),
    };
  }

  function buildAnswerFeedback(question, selectedAnswer, options = {}) {
    const correctAnswer = getCorrectAnswerLabel(question);
    const isCorrect = selectedAnswer === correctAnswer;
    const showExplanation = options.showExplanation !== false;
    const explanationLine = showExplanation && question?.explanation ? ` Original fact: ${question.explanation}` : '';

    return {
      isCorrect,
      correctAnswer,
      message: isCorrect
        ? `Correct. Correct answer: ${correctAnswer}.${explanationLine}`
        : `Wrong. Correct answer: ${correctAnswer}.${explanationLine}`,
    };
  }

  const api = {
    QUIZ_SCORE_KEY,
    DEFAULT_QUIZ_SCORE,
    sanitizeQuizScore,
    getFactsByCategory,
    pickRandomQuestion,
    createFalseStatement,
    generateTrueFalseQuestion,
    generateQuizQuestion,
    getCorrectAnswerLabel,
    updateQuizScore,
    buildAnswerFeedback,
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }

  globalScope.QuizUtils = api;
})(typeof globalThis !== 'undefined' ? globalThis : window);
