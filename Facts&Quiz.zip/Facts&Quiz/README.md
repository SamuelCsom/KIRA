# Random Smart Facts

Random Smart Facts is a Chrome Extension that shows a polished, fast-loading fact popup with a premium glassmorphism dark UI. The project now goes beyond MVP by adding categories, favorites, saved user preferences, and basic project-quality tooling.

## What the extension does

- Shows a random smart fact in a compact popup.
- Lets users filter facts by category.
- Lets users save favorite facts and browse only favorites.
- Remembers user preferences through an options page.
- Handles empty states and loading/storage failures gracefully.

## Main features

- **Premium popup UI** with the original dark glass visual preserved.
- **Category filter** with an `All` option.
- **Favorites** stored in `chrome.storage.local`.
- **Favorites-only mode** in the popup and as a saved default preference.
- **Options page** for default category, auto-refresh behavior, and default favorites filter.
- **Dataset validation script** for release confidence.
- **Small testable utilities** with Node-based tests.

## Project structure

- `manifest.json` – Manifest V3 configuration and extension permissions/options page.
- `popup.html` – Popup markup.
- `popup.js` – Popup orchestration, filtering, storage integration, and UX states.
- `options.html` – Settings screen for saved preferences.
- `options.js` – Options page logic and sync storage integration.
- `styles.css` – Shared premium dark glass styles for popup and options page.
- `facts.json` – Structured facts dataset with categories.
- `fact-utils.js` – Shared utility functions for validation, filtering, random selection, and settings sanitization.
- `scripts/validate-facts.js` – Dataset validation script.
- `tests/fact-utils.test.js` – Utility tests.

## How to load the extension locally in Chrome

1. Open Chrome and go to `chrome://extensions`.
2. Enable **Developer mode**.
3. Click **Load unpacked**.
4. Select the project folder.
5. Pin **Random Smart Facts** to the toolbar if you want quicker access.
6. Open the popup and verify categories, favorites, and settings.

## Development commands

```bash
npm run validate:facts
npm test
```

## Technologies used

- **Chrome Extension Manifest V3**
- **Vanilla HTML, CSS, and JavaScript**
- **chrome.storage.local** for favorites
- **chrome.storage.sync** for user settings
- **Node.js built-in test runner** for lightweight validation

## Future ideas

- Add fact search.
- Add localization support.
- Add richer categories or tags.
- Add import/export for favorites.
- Add CI validation for dataset and tests.
- Add subtle fact transition animations.
