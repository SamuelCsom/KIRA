(function attachPopupFacts(globalScope) {
  const { ALL_CATEGORIES, filterFacts, pickRandomFact, buildEmptyStateMessage } = globalScope.FactUtils;

  function createFactsController(elements, getFacts, getFavorites, setStatus, rotationState = {}) {
    let currentFact = null;
    let lastFactId = null;

    function getActiveFilters() {
      return {
        category: elements.categorySelect.value || ALL_CATEGORIES,
        favoritesOnly: elements.favoritesOnlyToggle.checked,
        favoriteIds: getFavorites(),
      };
    }

    function buildFilterKey(filters) {
      const category = filters.category || ALL_CATEGORIES;
      if (!filters.favoritesOnly) {
        return `category:${category}|favorites:false`;
      }

      const favoriteIds = Array.isArray(filters.favoriteIds) ? [...filters.favoriteIds].sort() : [];
      return `category:${category}|favorites:true|ids:${favoriteIds.join(',')}`;
    }

    function sanitizeShownIds(shownIds, facts) {
      if (!Array.isArray(shownIds) || !Array.isArray(facts) || facts.length === 0) {
        return [];
      }

      const validIds = new Set(facts.map((fact) => fact.id));
      const uniqueIds = new Set();

      return shownIds.filter((id) => {
        if (typeof id !== 'string' || !validIds.has(id) || uniqueIds.has(id)) {
          return false;
        }

        uniqueIds.add(id);
        return true;
      });
    }

    function rememberShownFact(filterKey, fact, filteredFacts) {
      if (!fact?.id) {
        return;
      }

      const existingShownIds = sanitizeShownIds(rotationState.getShownIds?.(filterKey), filteredFacts);
      if (existingShownIds.includes(fact.id)) {
        return;
      }

      rotationState.setShownIds?.(filterKey, [...existingShownIds, fact.id]);
    }

    function renderFact(fact, message = '') {
      currentFact = fact;

      if (!fact) {
        elements.factText.textContent = message;
        elements.factCategory.textContent = elements.favoritesOnlyToggle.checked ? 'Favorites' : elements.categorySelect.value;
        setStatus('', false);
        elements.newFactButton.disabled = true;
        return null;
      }

      elements.factText.textContent = fact.text;
      elements.factCategory.textContent = fact.category;
      setStatus(message, Boolean(message));
      elements.newFactButton.disabled = false;
      return fact;
    }

    async function showRandomFact(options = {}) {
      const facts = await getFacts();
      const activeFilters = getActiveFilters();
      const filteredFacts = filterFacts(facts, activeFilters);
      const filterKey = buildFilterKey(activeFilters);

      if (filteredFacts.length === 0) {
        lastFactId = null;
        rotationState.clearShownIds?.(filterKey);
        renderFact(null, buildEmptyStateMessage(getActiveFilters()));
        return null;
      }

      if (options.preserveCurrent) {
        const preservedFact = filteredFacts.find((fact) => fact.id === currentFact?.id);
        if (preservedFact) {
          rememberShownFact(filterKey, preservedFact, filteredFacts);
          renderFact(preservedFact);
          lastFactId = preservedFact.id;
          return preservedFact;
        }
      }

      let shownIds = sanitizeShownIds(rotationState.getShownIds?.(filterKey), filteredFacts);
      if (shownIds.length >= filteredFacts.length) {
        shownIds = [];
      }

      let candidateFacts = filteredFacts.filter((fact) => !shownIds.includes(fact.id));
      if (candidateFacts.length === 0) {
        shownIds = [];
        candidateFacts = filteredFacts;
      }

      const nextFact = pickRandomFact(candidateFacts, lastFactId);

      renderFact(nextFact);
      lastFactId = nextFact.id;
      rememberShownFact(filterKey, nextFact, filteredFacts);
      return nextFact;
    }

    function getCurrentFact() {
      return currentFact;
    }

    function syncCurrentFactToRotation() {
      if (!currentFact?.id) {
        return;
      }

      getFacts()
        .then((facts) => {
          const filters = getActiveFilters();
          const filteredFacts = filterFacts(facts, filters);
          if (!filteredFacts.some((fact) => fact.id === currentFact.id)) {
            return;
          }

          rememberShownFact(buildFilterKey(filters), currentFact, filteredFacts);
        })
        .catch(() => {});
    }

    function setLastFactId(value) {
      lastFactId = value;
    }

    return { showRandomFact, renderFact, getCurrentFact, getActiveFilters, setLastFactId, syncCurrentFactToRotation };
  }

  globalScope.PopupFacts = { createFactsController };
})(typeof globalThis !== 'undefined' ? globalThis : window);
