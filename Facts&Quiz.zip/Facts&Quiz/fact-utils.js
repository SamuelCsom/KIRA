(function attachFactUtils(globalScope) {
  const SETTINGS_KEY = 'randomSmartFacts.settings';
  const FAVORITES_KEY = 'randomSmartFacts.favorites';
  const ALL_CATEGORIES = 'All';
  const DEFAULT_SETTINGS = {
    defaultCategory: ALL_CATEGORIES,
    autoRefreshOnOpen: true,
    defaultFavoritesOnly: false,
    defaultMode: 'facts',
    autoNextQuestion: false,
    showExplanations: true,
  };

  function normalizeFact(rawFact, index) {
    if (!rawFact || typeof rawFact !== 'object') {
      throw new Error(`Fact at index ${index} must be an object.`);
    }

    const id = typeof rawFact.id === 'string' ? rawFact.id.trim() : '';
    const text = typeof rawFact.text === 'string' ? rawFact.text.trim() : '';
    const category = typeof rawFact.category === 'string' ? rawFact.category.trim() : '';
    const subject = typeof rawFact.subject === 'string' ? rawFact.subject.trim() : '';
    const difficulty = typeof rawFact.difficulty === 'string' ? rawFact.difficulty.trim() : 'medium';

    if (!id || !text || !category) {
      throw new Error(`Fact at index ${index} is missing required fields.`);
    }

    return { id, text, category, subject: subject || text, difficulty, quizModes: ['true_false'] };
  }

  function validateFactsPayload(payload) {
    if (!payload || !Array.isArray(payload.facts) || payload.facts.length === 0) {
      throw new Error('facts.json must contain a non-empty facts array.');
    }

    const ids = new Set();
    const normalizedFacts = payload.facts.map((fact, index) => {
      const normalizedFact = normalizeFact(fact, index);

      if (ids.has(normalizedFact.id)) {
        throw new Error(`Duplicate fact id detected: ${normalizedFact.id}`);
      }

      ids.add(normalizedFact.id);
      return normalizedFact;
    });

    return normalizedFacts;
  }

  function getCategories(facts) {
    return [ALL_CATEGORIES, ...new Set(facts.map((fact) => fact.category))];
  }

  function filterFacts(facts, options) {
    const { category = ALL_CATEGORIES, favoritesOnly = false, favoriteIds = [] } = options || {};
    const favoriteSet = new Set(favoriteIds);

    return facts.filter((fact) => {
      const matchesCategory = category === ALL_CATEGORIES || fact.category === category;
      const matchesFavoriteFilter = !favoritesOnly || favoriteSet.has(fact.id);
      return matchesCategory && matchesFavoriteFilter;
    });
  }

  function pickRandomItem(items, lastItemId) {
    if (!Array.isArray(items) || items.length === 0) {
      return null;
    }

    if (items.length === 1) {
      return items[0];
    }

    const candidates = items.filter((item) => item.id !== lastItemId);
    const pool = candidates.length > 0 ? candidates : items;
    return pool[Math.floor(Math.random() * pool.length)];
  }

  function pickRandomFact(facts, lastFactId) {
    return pickRandomItem(facts, lastFactId);
  }

  function buildEmptyStateMessage(options) {
    const { category = ALL_CATEGORIES, favoritesOnly = false } = options || {};

    if (favoritesOnly && category !== ALL_CATEGORIES) {
      return `No favorite facts found in ${category} yet. Save one from the popup to see it here.`;
    }

    if (favoritesOnly) {
      return 'No saved favorites yet. Tap the star on any fact to build your collection.';
    }

    return `No facts found for ${category}. Try switching back to All.`;
  }

  function sanitizeSettings(rawSettings, categories) {
    const allowedCategories = new Set(categories || [ALL_CATEGORIES]);
    const defaultCategory =
      rawSettings && typeof rawSettings.defaultCategory === 'string' && allowedCategories.has(rawSettings.defaultCategory)
        ? rawSettings.defaultCategory
        : DEFAULT_SETTINGS.defaultCategory;

    return {
      defaultCategory,
      autoRefreshOnOpen:
        rawSettings && typeof rawSettings.autoRefreshOnOpen === 'boolean'
          ? rawSettings.autoRefreshOnOpen
          : DEFAULT_SETTINGS.autoRefreshOnOpen,
      defaultFavoritesOnly:
        rawSettings && typeof rawSettings.defaultFavoritesOnly === 'boolean'
          ? rawSettings.defaultFavoritesOnly
          : DEFAULT_SETTINGS.defaultFavoritesOnly,
      defaultMode:
        rawSettings?.defaultMode === 'quiz' || rawSettings?.defaultMode === 'progress'
          ? rawSettings.defaultMode
          : DEFAULT_SETTINGS.defaultMode,
      autoNextQuestion:
        rawSettings && typeof rawSettings.autoNextQuestion === 'boolean'
          ? rawSettings.autoNextQuestion
          : DEFAULT_SETTINGS.autoNextQuestion,
      showExplanations:
        rawSettings && typeof rawSettings.showExplanations === 'boolean'
          ? rawSettings.showExplanations
          : DEFAULT_SETTINGS.showExplanations,
    };
  }

  const api = {
    SETTINGS_KEY,
    FAVORITES_KEY,
    ALL_CATEGORIES,
    DEFAULT_SETTINGS,
    validateFactsPayload,
    getCategories,
    filterFacts,
    pickRandomItem,
    pickRandomFact,
    buildEmptyStateMessage,
    sanitizeSettings,
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }

  globalScope.FactUtils = api;
})(typeof globalThis !== 'undefined' ? globalThis : window);
