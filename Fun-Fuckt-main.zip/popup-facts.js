(function attachPopupFacts(globalScope) {
  const { ALL_CATEGORIES, filterFacts, pickRandomFact, buildEmptyStateMessage } = globalScope.FactUtils;

  function createFactsController(elements, getFacts, getFavorites, setStatus) {
    let currentFact = null;
    let lastFactId = null;

    function getActiveFilters() {
      return {
        category: elements.categorySelect.value || ALL_CATEGORIES,
        favoritesOnly: elements.favoritesOnlyToggle.checked,
        favoriteIds: getFavorites(),
      };
    }

    function renderFact(fact, message = '') {
      currentFact = fact;

      if (!fact) {
        elements.factText.textContent = message;
        elements.factCategory.textContent = elements.favoritesOnlyToggle.checked ? 'Favorites' : elements.categorySelect.value;
        setStatus('', false);
        elements.newFactButton.disabled = true;
        return null;
      }

      elements.factText.textContent = fact.text;
      elements.factCategory.textContent = fact.category;
      setStatus(message, Boolean(message));
      elements.newFactButton.disabled = false;
      return fact;
    }

    async function showRandomFact(options = {}) {
      const facts = await getFacts();
      const filteredFacts = filterFacts(facts, getActiveFilters());

      if (filteredFacts.length === 0) {
        lastFactId = null;
        renderFact(null, buildEmptyStateMessage(getActiveFilters()));
        return null;
      }

      const nextFact = options.preserveCurrent
        ? filteredFacts.find((fact) => fact.id === currentFact?.id) || pickRandomFact(filteredFacts, lastFactId)
        : pickRandomFact(filteredFacts, lastFactId);

      renderFact(nextFact);
      lastFactId = nextFact.id;
      return nextFact;
    }

    function getCurrentFact() {
      return currentFact;
    }

    function setLastFactId(value) {
      lastFactId = value;
    }

    return { showRandomFact, renderFact, getCurrentFact, getActiveFilters, setLastFactId };
  }

  globalScope.PopupFacts = { createFactsController };
})(typeof globalThis !== 'undefined' ? globalThis : window);
