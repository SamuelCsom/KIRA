const factText = document.getElementById('fact-text');
const factCategory = document.getElementById('fact-category');
const statusText = document.getElementById('status-text');
const newFactButton = document.getElementById('new-fact-btn');
const favoriteButton = document.getElementById('favorite-btn');
const categorySelect = document.getElementById('category-select');
const favoritesOnlyToggle = document.getElementById('favorites-only-toggle');
const factsModeButton = document.getElementById('facts-mode-btn');
const quizModeButton = document.getElementById('quiz-mode-btn');
const factsPanel = document.getElementById('facts-panel');
const quizPanel = document.getElementById('quiz-panel');
const quizScoreCorrect = document.getElementById('quiz-score-correct');
const quizScoreWrong = document.getElementById('quiz-score-wrong');
const quizCategoryHint = document.getElementById('quiz-category-hint');
const quizQuestion = document.getElementById('quiz-question');
const quizOptions = document.getElementById('quiz-options');
const quizFeedback = document.getElementById('quiz-feedback');
const nextQuestionButton = document.getElementById('next-question-btn');

const { FAVORITES_KEY, SETTINGS_KEY, ALL_CATEGORIES, filterFacts, validateFactsPayload, getCategories, sanitizeSettings } = FactUtils;
const { getStorageArea, storageGet, storageSet } = StorageHelpers;
const { QUIZ_SCORE_KEY, DEFAULT_QUIZ_SCORE, sanitizeQuizScore, updateQuizScore } = QuizUtils;
const CURRENT_FACT_KEY = 'randomSmartFacts.currentFactId';

let factsCache = null;
let favoriteIds = [];
let settings = { ...FactUtils.DEFAULT_SETTINGS };
let activeMode = 'facts';
let currentQuizScore = { ...DEFAULT_QUIZ_SCORE };
let storedCurrentFactId = null;

async function loadFacts() {
  if (factsCache) {
    return factsCache;
  }

  const response = await fetch(chrome.runtime.getURL('facts.json'));
  if (!response.ok) {
    throw new Error(`Failed to fetch facts.json (${response.status})`);
  }

  factsCache = validateFactsPayload(await response.json());
  return factsCache;
}

function setStatus(message, isVisible = true) {
  statusText.textContent = message;
  statusText.hidden = !isVisible || !message;
}

function updateFavoriteButton(currentFact) {
  if (!currentFact) {
    favoriteButton.textContent = '\u2606';
    favoriteButton.setAttribute('aria-pressed', 'false');
    favoriteButton.disabled = true;
    return;
  }

  const isFavorite = favoriteIds.includes(currentFact.id);
  favoriteButton.textContent = isFavorite ? '\u2605' : '\u2606';
  favoriteButton.setAttribute('aria-pressed', String(isFavorite));
  favoriteButton.setAttribute('aria-label', isFavorite ? 'Remove current fact from favorites' : 'Save current fact to favorites');
  favoriteButton.disabled = false;
}

function renderCategoryOptions(categories, selectedCategory) {
  categorySelect.innerHTML = '';
  categories.forEach((category) => {
    const option = document.createElement('option');
    option.value = category;
    option.textContent = category;
    option.selected = category === selectedCategory;
    categorySelect.appendChild(option);
  });
}

function renderQuizScore() {
  quizScoreCorrect.textContent = String(currentQuizScore.correct);
  quizScoreWrong.textContent = String(currentQuizScore.wrong);
}

async function saveQuizScore() {
  await storageSet(getStorageArea('local'), {
    [QUIZ_SCORE_KEY]: {
      ...currentQuizScore,
    },
  });
}

function applyScoreUpdate(isCorrect) {
  currentQuizScore = updateQuizScore(currentQuizScore, isCorrect);
}

async function loadStoredState(categories) {
  const [storedFavorites, storedSettings, storedQuizScore, savedCurrentFactId] = await Promise.all([
    storageGet(getStorageArea('local'), FAVORITES_KEY).catch(() => []),
    storageGet(getStorageArea('sync'), SETTINGS_KEY).catch(() => null),
    storageGet(getStorageArea('local'), QUIZ_SCORE_KEY).catch(() => DEFAULT_QUIZ_SCORE),
    storageGet(getStorageArea('local'), CURRENT_FACT_KEY).catch(() => null),
  ]);

  favoriteIds = Array.isArray(storedFavorites) ? storedFavorites : [];
  settings = sanitizeSettings(storedSettings, categories);
  currentQuizScore = sanitizeQuizScore(storedQuizScore);
  storedCurrentFactId = typeof savedCurrentFactId === 'string' && savedCurrentFactId ? savedCurrentFactId : null;
}

async function saveFavorites() {
  await storageSet(getStorageArea('local'), { [FAVORITES_KEY]: favoriteIds });
}

async function saveCurrentFactId(factId) {
  storedCurrentFactId = typeof factId === 'string' && factId ? factId : null;
  await storageSet(getStorageArea('local'), { [CURRENT_FACT_KEY]: storedCurrentFactId });
}

async function showAndPersistFact(options) {
  const fact = await factsController.showRandomFact(options);
  await saveCurrentFactId(fact?.id || null);
  return fact;
}

function getRestoredFact(facts) {
  if (!storedCurrentFactId) {
    return null;
  }

  const visibleFacts = filterFacts(facts, factsController.getActiveFilters());
  return visibleFacts.find((fact) => fact.id === storedCurrentFactId) || null;
}

const factsController = PopupFacts.createFactsController({ factText, factCategory, categorySelect, favoritesOnlyToggle, newFactButton }, loadFacts, () => favoriteIds, setStatus);
const quizController = PopupQuiz.createQuizController(
  { categorySelect, quizCategoryHint, quizQuestion, quizOptions, quizFeedback, nextQuestionButton },
  {
    ALL_CATEGORIES,
    getFacts: loadFacts,
    getAutoNext: () => settings.autoNextQuestion,
    getShowExplanation: () => settings.showExplanations,
    onAnswered: async (_question, isCorrect) => {
      applyScoreUpdate(isCorrect);
      renderQuizScore();
      await saveQuizScore();
    },
    showNextQuestion: () => quizController.showNextQuestion(),
  }
);

function setActiveMode(mode) {
  activeMode = mode;
  const isFactsMode = mode === 'facts';
  factsModeButton.classList.toggle('is-active', isFactsMode);
  factsModeButton.setAttribute('aria-pressed', String(isFactsMode));
  quizModeButton.classList.toggle('is-active', !isFactsMode);
  quizModeButton.setAttribute('aria-pressed', String(!isFactsMode));
  factsPanel.hidden = !isFactsMode;
  quizPanel.hidden = isFactsMode;

  if (!isFactsMode) {
    quizController.showNextQuestion();
  }
}

async function toggleFavorite() {
  const currentFact = factsController.getCurrentFact();
  if (!currentFact) {
    return;
  }

  const isFavorite = favoriteIds.includes(currentFact.id);
  favoriteIds = isFavorite ? favoriteIds.filter((id) => id !== currentFact.id) : [...favoriteIds, currentFact.id];
  updateFavoriteButton(currentFact);
  await saveFavorites();

  if (favoritesOnlyToggle.checked && isFavorite) {
    const nextFact = await showAndPersistFact();
    updateFavoriteButton(nextFact);
    return;
  }

  setStatus(isFavorite ? 'Removed from favorites.' : 'Saved to favorites.');
}

async function initializePopup() {
  try {
    const facts = await loadFacts();
    const categories = getCategories(facts);

    await loadStoredState(categories);
    renderCategoryOptions(categories, settings.defaultCategory);
    favoritesOnlyToggle.checked = settings.defaultFavoritesOnly;
    renderQuizScore();
    quizController.updateCategoryHint();

    let initialFact = null;

    if (settings.autoRefreshOnOpen) {
      initialFact = await showAndPersistFact();
    } else {
      const restoredFact = getRestoredFact(facts);
      if (restoredFact) {
        factsController.renderFact(restoredFact);
        factsController.setLastFactId(restoredFact.id);
        await saveCurrentFactId(restoredFact.id);
        initialFact = restoredFact;
      } else {
        initialFact = await showAndPersistFact();
      }
    }

    updateFavoriteButton(initialFact);
    setActiveMode(settings.defaultMode || 'facts');
  } catch (error) {
    factText.textContent = "Sorry, we couldn't load facts right now. Please reload the extension and try again.";
    factCategory.textContent = 'Unavailable';
    newFactButton.disabled = true;
    favoriteButton.disabled = true;
    console.error(error);
  }
}

newFactButton.addEventListener('click', async () => {
  setStatus('', false);
  updateFavoriteButton(await showAndPersistFact());
});

categorySelect.addEventListener('change', async () => {
  setStatus('', false);
  updateFavoriteButton(await showAndPersistFact({ preserveCurrent: true }));
  quizController.resetSourceFactRotation();
  quizController.updateCategoryHint();
  if (activeMode === 'quiz') {
    await quizController.showNextQuestion();
  }
});

favoritesOnlyToggle.addEventListener('change', async () => {
  setStatus('', false);
  updateFavoriteButton(await showAndPersistFact({ preserveCurrent: true }));
});

favoriteButton.addEventListener('click', toggleFavorite);
factsModeButton.addEventListener('click', () => setActiveMode('facts'));
quizModeButton.addEventListener('click', () => setActiveMode('quiz'));
nextQuestionButton.addEventListener('click', () => quizController.showNextQuestion());

initializePopup();
