(function attachPopupQuiz(globalScope) {
  const {
    getFactsByCategory,
    pickRandomQuestion,
    generateTrueFalseQuestion,
    getCorrectAnswerLabel,
    buildAnswerFeedback,
  } = globalScope.QuizUtils;

  function createQuizController(elements, deps) {
    let currentQuestion = null;
    let lastSourceFactId = null;
    let autoNextTimer = null;

    function clearAutoNext() {
      if (autoNextTimer) {
        clearTimeout(autoNextTimer);
        autoNextTimer = null;
      }
    }

    function updateCategoryHint() {
      const selectedCategory = elements.categorySelect.value || deps.ALL_CATEGORIES;
      elements.quizCategoryHint.textContent =
        selectedCategory === deps.ALL_CATEGORIES
          ? 'Using all categories to generate natural true / false statements from the facts dataset.'
          : `Using ${selectedCategory} facts to generate natural true / false statements.`;
    }

    function renderQuestion(question) {
      currentQuestion = question;
      elements.quizOptions.innerHTML = '';
      elements.quizFeedback.hidden = true;
      elements.quizFeedback.textContent = '';
      elements.quizFeedback.dataset.state = '';
      elements.nextQuestionButton.disabled = true;
      clearAutoNext();

      if (!question) {
        elements.quizQuestion.textContent = 'No high-quality true / false question could be generated for this filter right now.';
        return;
      }

      elements.quizQuestion.textContent = question.statement;

      ['True', 'False'].forEach((option, index) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = `quiz-option quiz-option-${option.toLowerCase()}`;
        button.textContent = option;
        button.dataset.value = option;
        button.setAttribute('role', 'listitem');
        button.addEventListener('click', () => handleAnswer(option));
        button.addEventListener('keydown', (event) => handleOptionKeydown(event, index));
        elements.quizOptions.appendChild(button);
      });
    }

    function handleOptionKeydown(event, index) {
      const buttons = [...elements.quizOptions.querySelectorAll('.quiz-option')];
      if (!['ArrowLeft', 'ArrowRight', 'ArrowDown', 'ArrowUp'].includes(event.key)) {
        return;
      }

      event.preventDefault();
      const offset = event.key === 'ArrowLeft' || event.key === 'ArrowUp' ? -1 : 1;
      const nextIndex = (index + offset + buttons.length) % buttons.length;
      buttons[nextIndex]?.focus();
    }

    function decorateOptions(selectedAnswer, correctAnswer) {
      const buttons = [...elements.quizOptions.querySelectorAll('.quiz-option')];
      buttons.forEach((button) => {
        const value = button.dataset.value;
        button.disabled = true;
        button.classList.toggle('is-selected', value === selectedAnswer);
        button.classList.toggle('is-correct', value === correctAnswer);
        button.classList.toggle('is-incorrect', value === selectedAnswer && value !== correctAnswer);
      });
    }

    async function handleAnswer(selectedAnswer) {
      if (!currentQuestion) {
        return;
      }

      const correctAnswer = getCorrectAnswerLabel(currentQuestion);
      const feedback = buildAnswerFeedback(currentQuestion, selectedAnswer, {
        showExplanation: deps.getShowExplanation(),
      });

      decorateOptions(selectedAnswer, correctAnswer);
      elements.nextQuestionButton.disabled = false;
      await deps.onAnswered(currentQuestion, feedback.isCorrect, feedback.correctAnswer);

      elements.quizFeedback.textContent = feedback.message;
      elements.quizFeedback.hidden = false;
      elements.quizFeedback.dataset.state = feedback.isCorrect ? 'correct' : 'incorrect';
      elements.nextQuestionButton.focus();

      if (deps.getAutoNext()) {
        autoNextTimer = setTimeout(() => {
          deps.showNextQuestion();
        }, 1800);
      }
    }

    async function showNextQuestion() {
      const facts = await deps.getFacts();
      const factsForQuiz = getFactsByCategory(facts, elements.categorySelect.value || deps.ALL_CATEGORIES);
      const attempts = Math.min(factsForQuiz.length, 12);
      let sourceFact = null;
      let nextQuestion = null;

      for (let attempt = 0; attempt < attempts; attempt += 1) {
        sourceFact = pickRandomQuestion(factsForQuiz, attempt === 0 ? lastSourceFactId : sourceFact?.id);
        nextQuestion = sourceFact ? generateTrueFalseQuestion(sourceFact, factsForQuiz) : null;
        if (nextQuestion) {
          break;
        }
      }

      updateCategoryHint();
      renderQuestion(nextQuestion);
      if (nextQuestion) {
        lastSourceFactId = nextQuestion.sourceFactId;
      }
    }

    function resetSourceFactRotation() {
      lastSourceFactId = null;
      clearAutoNext();
    }

    return { updateCategoryHint, renderQuestion, showNextQuestion, resetSourceFactRotation, clearAutoNext };
  }

  globalScope.PopupQuiz = { createQuizController };
})(typeof globalThis !== 'undefined' ? globalThis : window);
