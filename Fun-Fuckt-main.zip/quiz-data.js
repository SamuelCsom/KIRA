(function attachQuizData(globalScope) {
  const CATEGORY_TERMS = {
    Space: ['Mercury', 'Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Moon', 'Sun', 'Milky Way', 'Andromeda', 'Europa', 'Titan', 'Triton'],
    Animals: ['lion', 'dog', 'cat', 'whale', 'dolphin', 'bat', 'penguin', 'ostrich', 'elephant', 'giraffe', 'cheetah', 'koala', 'kangaroo', 'platypus', 'shark', 'octopus', 'spider', 'butterfly', 'owl', 'eagle', 'panda'],
    Nature: ['Pacific Ocean', 'Atlantic Ocean', 'Arctic', 'Antarctica', 'Amazon Rainforest', 'Sahara', 'Mount Everest', 'Moon', 'Sun', 'lightning', 'rainbow', 'fog', 'frost', 'glacier', 'tornado'],
    History: ['Ancient Egypt', 'China', 'Rome', 'Greece', 'Athens', 'Sparta', 'Julius Caesar', 'Augustus', 'Leonardo da Vinci', 'Napoleon Bonaparte', 'Abraham Lincoln', 'Yuri Gagarin', 'Mahatma Gandhi', 'Nelson Mandela'],
    Technology: ['computer', 'software', 'hardware', 'CPU', 'RAM', 'hard drive', 'SSD', 'keyboard', 'monitor', 'mouse', 'router', 'modem', 'Wi-Fi', 'Bluetooth', 'USB', 'HTML', 'CSS', 'JavaScript', 'Git'],
    Science: ['water', 'oxygen', 'carbon', 'hydrogen', 'helium', 'iron', 'gold', 'DNA', 'genes', 'cells', 'gravity', 'light', 'sound', 'electricity', 'temperature', 'enzymes', 'viruses'],
  };

  const NUMBER_REPLACEMENTS = {
    '99%': '9%',
    '8 minutes': '8 seconds',
    '24 hours': '48 hours',
    '1969': '1979',
    '1990': '1980',
    '4.6 billion': '460 million',
    '4.5 billion': '450 million',
    '1215': '1251',
    '1066': '1606',
    '1776': '1876',
    '1789': '1889',
    '1914': '1924',
    '1918': '1908',
    '1939': '1949',
    '1945': '1955',
    '1991': '1981',
    largest: 'smallest',
    smallest: 'largest',
    hottest: 'coldest',
    closest: 'farthest',
    farthest: 'closest',
    north: 'south',
  };

  const api = {
    CATEGORY_TERMS,
    NUMBER_REPLACEMENTS,
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }

  globalScope.QuizData = api;
})(typeof globalThis !== 'undefined' ? globalThis : window);
